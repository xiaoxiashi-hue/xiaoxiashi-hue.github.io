This folder contains the complete collection of the Gauss programs that produced the Monte Carlo simulations in Andrews and Shi (2013, Econometrica) (url: http://cowles.econ.yale.edu/P/cd/d17b/d1761-rra.pdf).

The programs run in Gauss 6.0 or higher (Aptech: http://www.aptech.com/) but can be viewed and edited in any text editor. 

The programs use a Gauss application "CO" for constrained optimization: http://www.aptech.com/products/gauss-applications/constrained-optimization/

Below, we describe the files in this folder:

The "as", "clr", "lswcode" prefixes in the file names indicates that the code implement the "Andrews and Shi (2013) method", "Chernozhukov, Lee and Rosen (2013, Econometrica) method", and "Lee, Song and Whang (2011) method", respectively.

"entry_game" in the file names indicates that the code is for the entry game example reported in Section 10.4 of Andrews and Shi (2013).

"interval_outcome" indicates that the code is for the interval outcome example reported in Section 17.3 of the Supplemental material of Andrews and Shi (2013).

"intersection_bd" indicates that the code is for the intersection bound example reported in Section 10.3 of Andrews and Shi (2013)

"ms" indicates that the code is for the mean selection example reported in Section 17.2 of Andrews and Shi (2013)

"qs" indicates that the code is for the quantile selection example reported in Section 10.2 of Andrews and Shi (2013)

"kernel" indicates that the kernel (local linear) version of the Chernozhukov, Lee and Rosen (2013, Econometrica) is implemented.

"series" indicates that the series version of the Chernozhukov, Lee and Rosen (2013, Econometrica" is implemented. 

References:
Please refer to the paper (link provided above) for references mentioned in this readme file. 

Please send questions and inquiries to xiaoxia.shi@gmail.com or donald.andrews@yale.edu. 

Donald W. K. Andrews and Xiaoxia Shi are owners of the programs in this folder and this readme file. All rights reserved.