 
clear;
%tic

%Set up inputs 
nrep = 10000;
m = 200;            % sample size 1
n = 200;            % sample size 2 

delta = 0.065;      % tuning parameter for p=1. Obtain the recommended delta 
                    % choices using the function delta_star.m beforehand.
delta2 = 0.060;     % tuning parameter for p=2

%The parameter on the x-axis of the graphs in the paper:
odcpar_0 = 0;       % starting point of range of odcpar
odcpar_step = 0.05; % step
odcpar_1 = 0.9;     % ending point of range of odcpar

%set the data generating process
design = 1;         % 
isconcave = 1;      % (design, isconcave) = (1,1): R^{0,I}
                    %                       (1,0): R^{1,III}
                    %                       (2,1): R^{0,II}
                    %                       (2,0): R^{1,IV}

ngrid = 100;        % number of grids 
sig = 0.05;         % desired significance level



odcpar_range = odcpar_0:odcpar_step:odcpar_1;
nodcpar = length(odcpar_range);

TL1 = zeros(nrep,nodcpar);
TL2 =  zeros(nrep,nodcpar);
TLinf =  zeros(nrep,nodcpar);
TbsL1 = zeros(nrep,nodcpar);
TbsL2 = zeros(nrep,nodcpar);
TbsLinf = zeros(nrep,nodcpar);

rng('default');
tic
for seed = 1:nrep
    %Setting up data
    rng(seed);
    x = rand(m,1);
    y = rand(n,1);
    xindxbs = ceil(m*rand(m,1));
    yindxbs = ceil(n*rand(n,1));
    stats = zeros(nodcpar,4);

    %Compute the test stat and the bootstrap stat (using Warp speed bootstrap
    %per Giacomini and White)
    ip = 1;
    for odcpar = odcpar_0:odcpar_step:odcpar_1
        stats(ip,:) = singlerep_static(m,n,delta,delta2,odcpar,x,y,xindxbs,yindxbs,design,isconcave,ngrid);
        ip = ip+1;
        display([seed,ip,toc]);
    end
    
    TL1(seed,:) = stats(:,1)';
    TL2(seed,:) = stats(:,2)';
    TbsL1(seed,:) = stats(:,3)';
    TbsL2(seed,:) = stats(:,4)';

end


% calculate bootstrap critical value 
cvbsL1 = quantile(TbsL1,1-sig);
cvbsL2 = quantile(TbsL2,1-sig);

%rejection rate of the bootstrap test
BSL1 = mean(TL1>repmat(cvbsL1,nrep,1));
BSL2 = mean(TL2>repmat(cvbsL2,nrep,1));

%rejection rate of size uncorrected BM test
BML1 = mean(TL1>0.64364);
BML2 = mean(TL2>0.74122);

%rejection rate of size-corrected BM test
[szcrBML1,szcrBML2] = BMszcr(m,n,ngrid,nrep,sig);
BMLad1 = mean(TL1>0.64364+szcrBML1);
BMLad2 = mean(TL2>0.74122+szcrBML2);


fid = fopen('case1.txt','w');    %store the rejection rates in this txt file, overwriting if file exists
fprintf(fid, 'odcpar, BML1, BML2, BSL1, BSL2, BMLad1, BMLad2, m,n\n');
for x = 1:nodcpar
    
    fprintf('%1.6f, %1.4f, %1.4f, %1.4f, %1.4f, %1.4f,%1.4f, %g, %g\n',...
        [odcpar_range(x),BML1(x), BML2(x), BSL1(x), BSL2(x), BMLad1(x), BMLad2(x), m,n]);
    fprintf(fid, '%1.6f, %1.4f, %1.4f, %1.4f, %1.4f, %1.4f,%1.4f, %g, %g\n',...
        [odcpar_range(x),BML1(x), BML2(x), BSL1(x), BSL2(x), BMLad1(x), BMLad2(x), m,n]);
end
fclose(fid);





