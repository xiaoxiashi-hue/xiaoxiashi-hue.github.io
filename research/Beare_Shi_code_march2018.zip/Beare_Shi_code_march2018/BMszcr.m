%Compute Size Correction For BM L1 and L2 tests.
%Inputs:
%m;            % sample size 1
%n;            % sample size 2
%nrep;         % number of simulation repetitions
%ngrid;        % grid points used
%sig;          % significance level

%The computation time for this function is not significant.

function [szcrBML1,szcrBML2] = BMszcr(m,n,ngrid,nrep,sig);
%tic

%Set the curve to be 45 degree line, that is, the least favorable case 
odcpar = 0;         % starting point of range of odcpar
design = 1;         % check which simulation design is used
isconcave = 1;      % determine whether the cdf is concave or not

TL1 = zeros(nrep,1);
TL2 =  zeros(nrep,1);
rng('default');
tic
for seed = 1:nrep
    %Setting up data
    rng(seed);
    x = rand(m,1);
    y = rand(n,1);

    %Compute the test stat and the bootstrap stat (using Warp speed bootstrap
    %per Giacomini and White)
     stats = singlerep_TestStat(m,n,odcpar,x,y,design,isconcave,ngrid);
    
    TL1(seed,:) = stats(1)';
    TL2(seed,:) = stats(2)';

end

% calculate size correction needed for fixed critical value test
szcrBML1 = quantile(TL1,1-sig)-0.64364;
szcrBML2 = quantile(TL2,1-sig)-0.74122;





