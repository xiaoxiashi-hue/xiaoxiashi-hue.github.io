function f = singlerep_static(m,n,delta1,delta2,gamma,x,y,xindxbs,yindxbs,design,isconcave,ngrid)   

f = zeros(1,4);
c = sqrt(m*n/(m+n));
lambda = m/(m+n);

xindx = 1:m;
x = sort(x);    %generate data
y = sort(y);    %generate data

% design 1 : Simulation Design 1
% design 2 : Simulation Design 2
% isconcave : if 1 then concave, else nonconcave

if design == 1
    if isconcave == 1 
        thres=(1+gamma)/2;

        for i = 1:m
            if x(i) <= thres
                x(i) = ((1-gamma)/(1+gamma))*x(i);
            else
                x(i) = (x(i)-2*gamma/(1+gamma))*(1+gamma)/(1-gamma);
            end
        end
    else
        thres1 = (7-3*gamma)/8;
        thres2 = (49-18*gamma)/56;
        thres3 = (49+3*gamma)/56;
        
        for i = 1:m
            if x(i) <= thres1
               x(i) = x(i)/7; 
            elseif x(i) <= thres2
               x(i) = 7*x(i) - (42-18*gamma)/7; 
            elseif x(i) <= thres3
               x(i) = x(i)/7 + 18*gamma/49;  
            else
               x(i) = 7*x(i) - 6; 
            end
        end
    end
    
elseif design == 2
    if isconcave == 1
        thres1=(1+2*gamma)/4;
        thres2=(3+2*gamma)/4;
        for i = 1:m
            if x(i) <= thres1
                x(i) = ((1-2*gamma)/(1+2*gamma))*x(i);
            elseif x(i) > thres2
                x(i) = ((1+2*gamma)/(1-2*gamma))*x(i) - 4*gamma/(1-2*gamma);
            else
                x(i) = x(i)-gamma;
            end
        end
        
    else
        gamma2 = 0.3;
        thres1=(1+2*gamma2)/4;
        thres2=(3+2*gamma2)/4;
        
        for i=1:m 
            if x(i) <= thres1
                x(i) = ((1-2*gamma2)/(1+2*gamma2))*x(i);
            elseif x(i) > thres2
                x(i) = ((1+2*gamma2)/(1-2*gamma2))*x(i) - 4*gamma2/(1-2*gamma2);
            else
                if gamma == 0
                    x(i) = x(i) - gamma2;
                else
                    a1 = (1-2*gamma2)/4;
                    a2 = (3-2*gamma2)/4;
                    a3 = a1+a2;
                    a4 = a1*a2;
                    a5 = (a3-1/gamma)/2;
                    temp1 = (x(i)-gamma2)/gamma + a5^2 - a4;
                    x(i) = sqrt(temp1)+a5;
                end
            end
        end
        
    end
end   

% See chapter 4 for further detail
%%% Compute the test statistic %%%

Rmn = zeros(ngrid+1,1);
qy = quantile(y,[0,1:ngrid]/ngrid);  %quantile calculation with ngrid 

for i = 1:ngrid
    if x(1)<=qy(i+1)
        Rmn(i+1) = max(xindx(x <= qy(i+1)))/m;
    end
end

SRmn = zeros(ngrid+1,ngrid+1,ngrid+1);
for i = 0:ngrid
    for j = 0:i
        for k = i:ngrid
            if (i-j)*(k-i)==0
                SRmn(i+1,j+1,k+1) = Rmn(i+1);
            else
                SRmn(i+1,j+1,k+1) = ((k-i)*Rmn(j+1)+(i-j)*Rmn(k+1))/(k-j);
            end
        end
    end
end
MRmn = max(max(SRmn,[],3),[],2);

%Comupte M_m,n and store thre value in f 
f(1,1) = (c/ngrid)*(MRmn(1)/2+MRmn(ngrid+1)/2+sum(MRmn(2:ngrid))-sum(Rmn));   %Test stat L1
f(1,2) = c*sqrt(sum((1/3)*(MRmn(2:ngrid+1)-MRmn(1:ngrid)).^2+...
    (MRmn(1:ngrid)-Rmn(2:ngrid+1)).*(MRmn(2:ngrid+1)-Rmn(2:ngrid+1)))/ngrid); %Test stat L2


%%% Determine which of the relevant points in the unit cube belong to the
%%% estimated contact set 

Rprime = zeros(ngrid+1);  %Estimated derivative of Rmn, 
                          %used for constructing threshold
band_der = ceil(ngrid/n^(2/3)); %bandwidth used for estimating
                                %the derivative
for i = 0:ngrid
    up = min(ngrid+1,i+1+band_der);
    lw = max(1,i+1 - band_der);
    Rprime(i+1) = ngrid*(Rmn(up)-Rmn(lw))/(up-lw);
end
    
b1 = zeros(ngrid+1,ngrid+1,ngrid+1);
b2 = zeros(ngrid+1,ngrid+1,ngrid+1);
b3 = zeros(ngrid+1,ngrid+1,ngrid+1);
var = zeros(ngrid+1,ngrid+1,ngrid+1);
for i = 0:ngrid
    for j = 0:i
        for k = i:ngrid
            if k==j
               b1(i+1,j+1,k+1)=1;
               b2(i+1,j+1,k+1)=1;
               b3(i+1,j+1,k+1)=1;
            else
            var(i+1,j+1,k+1) = lambda*(k-i)^2*(Rmn(i+1)-Rmn(j+1))/(k-j)^2 ...
                              +lambda*(i-j)^2*(Rmn(k+1)-Rmn(i+1))/(k-j)^2 ...
                              +(1-lambda)*(((k-i)^2/(k-j)^2)/ngrid)* ...
             (Rprime(j+1)^2*(j+1)+Rprime(i+1)^2*(i+1)-2*Rprime(i+1)*Rprime(j+1)*(j+1))...
                              +(1-lambda)*(((i-j)^2/(k-j)^2)/ngrid)*...
             (Rprime(k+1)^2*(k+1)+Rprime(i+1)^2*(i+1)-2*Rprime(k+1)*Rprime(i+1)*(i+1))...
                        +2*(1-lambda)*(((k-i)*(i-j)/(k-j)^2)/ngrid)*...
             (Rprime(k+1)-Rprime(i+1))*(Rprime(j+1)*(j+1)-Rprime(i+1)*(i+1));
         
            concave1 = (MRmn(i+1)-Rmn(i+1)<=delta1);
            concave2 = (MRmn(i+1)-Rmn(i+1)<=delta2);
            deltaijk1 = sqrt(var(i+1,j+1,k+1))*delta1;
            deltaijk2 = sqrt(var(i+1,j+1,k+1))*delta2;
            b1(i+1,j+1,k+1) = concave1*(abs(SRmn(i+1,j+1,k+1)-Rmn(i+1))<=deltaijk1);
            b2(i+1,j+1,k+1) = concave2*(abs(SRmn(i+1,j+1,k+1)-Rmn(i+1))<=deltaijk2);
                              
            end
        end
    end
end



%%% Generate the bootstrap critical value %%%

% Generate bootstrap samples 
xbs = sort(x(xindxbs));
ybs = sort(y(yindxbs));

qybs = quantile(ybs,[0,1:ngrid]/ngrid);
Rmnbs = zeros(ngrid+1,1);

% Compute R_m,n^* and SR_m,n^*

for i = 1:ngrid
    if xbs(1)<=qybs(i+1)
        Rmnbs(i+1) = max(xindx(xbs <= qybs(i+1)))/m;
    end
end
SRmnbs = zeros(ngrid+1,ngrid+1,ngrid+1);
for i = 0:ngrid
    for j = 0:i
        for k = i:ngrid
            if j==k
                SRmnbs(i+1,j+1,k+1) = Rmnbs(i+1);
            else
                SRmnbs(i+1,j+1,k+1) = ((k-i)*Rmnbs(j+1)+(i-j)*Rmnbs(k+1))/(k-j);
            end
        end
    end
end

% Compute StildeT_m,n^*

STmnbs = c*(SRmnbs-SRmn);
clear SRmnbs;
clear SRmn;
StildeTmnbs = zeros(ngrid+1,ngrid+1,ngrid+1);
for i = 0:ngrid
    StildeTmnbs(i+1,:,:) = STmnbs(i+1,:,:)-c*(Rmnbs(i+1)-Rmn(i+1));
end
clear STmnbs;

% Compute H_m,n^*

Hmnbs = max(max(b1.*StildeTmnbs,[],3),[],2);
Hmnbs2 = max(max(b2.*StildeTmnbs,[],3),[],2);
clear StildeTmnbs;
clear b b2 b3;

% Compute M_m,n^* using the numerical approximation and store in f 

f(1,3) = mean(Hmnbs);            %Bootstrap L1 stat
f(1,4) = sqrt(mean(Hmnbs2.^2));   %Bootstrap L2 stat
 