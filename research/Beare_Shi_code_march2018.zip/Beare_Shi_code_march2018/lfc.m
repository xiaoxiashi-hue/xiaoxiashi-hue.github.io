%Inputs:
%m;            % sample size 1
%n;            % sample size 2
%nrep;         % number of simulation repetitions
%ngrid;        % grid points used
%delta1;       % tuning parameter for BS L1 test
%delta2;       % tuning parameter for BS L2 test
%sig;          % significance level

function [BSL1,BSL2,szcrBML1,szcrBML2] = lfc(m,n,ngrid,nrep,delta1,delta2,sig);
%tic

%Set the curve to be 45 degree line, that is, the least favorable case 
odcpar = 0;         % starting point of range of odcpar
design = 1;         % check which simulation design is used
isconcave = 1;      % determine whether the cdf is concave or not

TL1 = zeros(nrep,1);
TL2 =  zeros(nrep,1);
TbsL1 = zeros(nrep,1);
TbsL2 = zeros(nrep,1);

rng('default');
tic
for seed = 1:nrep
    %Setting up data
    rng(seed);
    x = rand(m,1);
    y = rand(n,1);
    xindxbs = ceil(m*rand(m,1));
    yindxbs = ceil(n*rand(n,1));

    %Compute the test stat and the bootstrap stat (using Warp speed bootstrap
    %per Giacomini and White)
     stats = singlerep_static(m,n,delta1,delta2,odcpar,x,y,xindxbs,yindxbs,design,isconcave,ngrid);
    
    TL1(seed,:) = stats(1)';
    TL2(seed,:) = stats(2)';
    TbsL1(seed,:) = stats(3)';
    TbsL2(seed,:) = stats(4)';

end


% calculate bootstrap critical value 
cvbsL1 = quantile(TbsL1,1-sig);
cvbsL2 = quantile(TbsL2,1-sig);

% calculate bootstrap rej rate
BSL1 = mean(TL1>repmat(cvbsL1,nrep,1));
BSL2 = mean(TL2>repmat(cvbsL2,nrep,1));


% calculate size correction needed for fixed critical value test
szcrBML1 = quantile(TL1,1-sig)-0.64364;
szcrBML2 = quantile(TL2,1-sig)-0.74122;





