The code files included in this folder are Matlab m files. They can be used to 
reproduce all the graphs in Beare and Shi: "An Improved Bootstrap Test of Density
Ratio Ordering," and adapted to the user's specific density ratio ordering testing
problems.

The folder contains 6 m files. The user needs only directly interact with
impdro.m and perhaps delta_star.m.

*impdro.m: is the main executable that prints out the rejection rates. One should adjust
the values of the input variables (annotated in the file) to produce different 
graphs in the paper. Running impdro.m in Matlab 2016a without change reproduces
the output file case1.txt, which contains data that Figure 5.3 is based upon.

impdro calls for the Matlab functions singlerep_static.m and BMszcr.m provided 
in this folder.

impdro sets the tuning parameters delta1 and delta2 (delta for Bootstrap L1 and
L2 tests respectively) at fixed values. These fixed values should be chosen 
according to the recommendations in Section 4 of the paper. The recommended
values, if for a setting for which the recommended values are not given in the paper, 
can be computed using the function delta_star. The user should read
the comments in delta_star.m for details.


*delta_star.m: Matlab function that computes the recommended delta values for 
the Bootstrap L1 and L2 tests.

delta_star.m calls for the Matlab function lfc.m provided in this folder.

*BMszcr.m: Matlab function that computes size correction needed to bring the 
finite sample least favorable rejection rate of the BM tests to the nominal size.
This function is called in impdro.m.

*singlerep_static.m: Matlab function that computes the test statistics and the 
bootstrap statistics. This function is called in impdro.m.

*singlerep_TestStat.m: Matlab function that computes only the test statistics. 
This function is called in BMszcr.m.

*lfc.m: Matlab function that computes the least favorable case rejection rates
of the bootstrap L1 and L2 test. It can compute the size correction for the BM 
test at the same time, but BMszcr.m is faster for this particular purpose. 

lfc is called in delta_star.m.

lfc calls for the Matlab function singlerep_static.m.


************************************
Note on computation time: evaluating delta_star with m=n=200, ngrid=100, nrep = 10000
takes 3-4 hours on single thread.

Running impdro.m with m=n=200, ngrid=100, nrep=10000 takes about 8 hours on single
thread.

Computation time for both increases about 8-fold when ngrid doubles. It doubles
when nrep doubles. It increases somewhat less when m or n doubles. Therefore
one should be prepared to engage parallel computing technology if one desires to
use larger ngrid, especially if nrep and/or m and n are also large. 








