%Using bisection method to find the best delta1 and delta2

%Inputs:
%m;            % sample size 1
%n;            % sample size 2
%nrep;         % number of simulation repetitions
%ngrid;        % grid points used
%sig;          % significance level
%tol;          % tolerance for difference of obtained quantile from desired
%              % one. This is a tolerance on the function value.
%dtol:         % tolerance on the space of delta
%lwbd, upbd:   % lower bound and upper bound for the search

%Outputs?
%delta_starL1; %Recommended delta value for Bootstrap L1 test
%delta_starL2; %Recommended delta value for Bootstrap L2 test
%rpL1;         %simulated rejection probability in the lfc for Bootstrap L1
%              %Test
%rpL2;         %simulated rejection probability in the lfc for Bootstrap L2
%              %Test

%General Comments: the computation time increases linearly with nrep,
%increases less than linearly with m or n. The computational time increases
%at polynomial rate with ngrid. For example, if ngrid is doubled.
%the computation time increases roughly 8=2^3 fold. Before launching a
%full implementation of this function, one should assess the total time
%needed for ones application, and if necessary, engage parallel computing
%technology. 
%
%With m=n=200, ngrid=100, nrep = 10000, tol = dtol = 0.001, and lwbd =
%0.58, upbd = 0.68, the function takes 3-4 hours to evaluate on Surface Pro
%3 without parallel computing.


function [delta_starL1,delta_starL2,rpL1,rpL2] = delta_star(m,n,ngrid,nrep,sig,tol,dtol,lwbd,upbd)

delta_lwr0 = lwbd;
delta_upr0 = upbd;

%We do bisection for L1 first, and save the value for L2 in every step for
%later use. 

BSL2_vec = NaN(1000,1); %Suppose we need less than 500 steps for the convergence for L1
delta2_vec = NaN(1000,1);
[BSL1_l,BSL2_vec(1)] = lfc(m,n,ngrid,nrep,delta_lwr0,delta_lwr0,sig);
display([delta_lwr0,BSL1_l,BSL2_vec(1)]);
delta2_vec(1) = delta_lwr0;

[BSL1_u,BSL2_vec(2)] = lfc(m,n,ngrid,nrep,delta_upr0,delta_upr0,sig);
display([delta_upr0,BSL1_u,BSL2_vec(2)]);
delta2_vec(2) = delta_upr0;
ind = 2; %two values of BSL2 have been computed

delta_lwr = delta_lwr0;
delta_upr = delta_upr0;

conv1=0;
while conv1 == 0;
    if BSL1_l<sig;
        warning('Delta_starL1 = 0. Something is wrong.');
        conv1 = 1;
        delta_starL1 = delta_lwr;
                rpL1 = BSL1_l;
        continue;
    end;
    if BSL1_u > sig;       %if the upper is not big enough
        delta_upr_temp = delta_upr;
        delta_upr = delta_upr+(delta_upr-delta_lwr)*(BSL1_u - sig)/(BSL1_l-BSL1_u);
                               %linearly extrapolate to get the new upper
        delta_lwr = delta_upr_temp;
        BSL1_l = BSL1_u;       %set the old upper as lower
        [BSL1_u,BSL2_vec(ind+1)] = lfc(m,n,ngrid,nrep,delta_upr,delta_upr,sig);
        display([delta_upr,BSL1_u,BSL2_vec(ind+1)]);
                               %compute the cv at the new upper.
        delta2_vec(ind+1) = delta_upr;
        ind = ind+1;
    elseif BSL1_u>=sig-tol && BSL1_u<=sig; %if the upper is just big enough
        conv1 = 1;
        delta_starL1 = delta_upr;
                rpL1 = BSL1_u;
    elseif BSL1_u<sig-tol;         %if the upper is too big
        delta_mid = (delta_lwr+delta_upr)/2;   %compute midpoint
        %delta_mid = delta_lwr + (delta_upr-delta_lwr)*(BSL1_l - sig)/(BSL1_l-BSL1_u);
                             %linear intrapolation to find midpoint
                             
        [BSL1_m,BSL2_vec(ind+1)] = lfc(m,n,ngrid,nrep,delta_mid,delta_mid,sig);
        display([delta_mid,BSL1_m,BSL2_vec(ind+1)]);
        delta2_vec(ind+1) = delta_mid;
        ind = ind+1;
                               %compute cv at midpoint
        if BSL1_m>=sig-tol && BSL1_m<=sig; %if midpoint is just big enough
            conv1 = 1;
            delta_starL1 = delta_mid;
            rpL1 = BSL1_m;
        elseif BSL1_m>sig; %if midpoint is not big enough;
            delta_lwr = delta_mid; %set the midpoint as the new upper;
            BSL1_l = BSL1_m;     
        elseif BSL1_m<sig-tol; %if midpoint is too big;
            delta_upr = delta_mid; %set the midpoint as the new lower
            BSL1_u = BSL1_m;
        end
    end
    if delta_upr-delta_lwr<dtol;
        conv1=1;
        delta_starL1 = delta_upr;
        rpL1 = BSL1_u;
    end
    
%     %for debugging the L2 part of the code. Delete for usual application.
%     if ind>3;
%         conv1=1;
%         delta_starL1 = delta_upr;
%     end
end


%Now we find initial interval for doing bisection for L2
if max(BSL2_vec)<=sig; %if 0 is not aggressive, something is wrong
    delta_starL2 = 0;
    
    rpL2 = max(BSL2_vec);
    warning('Delta_starL2 = 0. Something is wrong.');
else  %otherwise find the highest delta that is not still not big enough.
    [BSL2_l, i] = min(BSL2_vec + (BSL2_vec<=sig)*999999);
    delta2_lwr = delta2_vec(i);
    
    if min(BSL2_vec)>sig;  %if all deltas are too aggressive, we linearly extrapolate to zero
        delta2_upr = delta2_lwr+(delta2_lwr-delta_lwr0)*(BSL2_l - sig)...
                                                     /(BSL2_vec(1)-BSL2_l);
        
       [~,BSL2_u] = lfc(m,n,ngrid,nrep,delta2_upr,delta2_upr,sig);
    else     %if some delta is not too aggressive, perhap even conservative
        [BSL2_u,ui] = max(BSL2_vec - (BSL2_vec>sig)*99999);  %find the one that is the least conservative
        delta2_upr = delta2_vec(ui);
    end
end

%bisection for L2
conv2 = 0;
while conv2==0;
    if BSL2_u<=sig && BSL2_u>=sig-tol;
        conv2 = 1;
        delta_starL2 = delta2_upr;
        rpL2 = BSL2_u;
    else  %if delta2_upr is too conservative
        delta2_mid = (delta2_lwr+delta2_upr)/2;
        %delta2_mid = delta2_lwr + (delta2_upr-delta2_lwr)*(BSL2_l - sig)...
        %                                              /(BSL2_l-BSL2_u);
                       %linear intrapolation to find midpoint
        [~,BSL2_m] = lfc(m,n,ngrid,nrep,delta2_mid,delta2_mid,sig);
        display([delta2_mid,BSL2_m]);
                               %compute cv at midpoint
        if BSL2_m>=sig-tol && BSL2_m<=sig; %if midpoint is just big enough
            conv2 = 1;
            delta_starL2 = delta2_mid;
            rpL2 = BSL2_m;
        elseif BSL2_m>sig; %if midpoint is not big enough;
            delta2_lwr = delta2_mid; %set the midpoint as the new upper;
       %     BSL2_l = BSL2_m;     
        elseif BSL2_m<sig-tol; %if midpoint is too big;
            delta2_upr = delta2_mid; %set the midpoint as the new lower
            BSL2_u = BSL2_m;
        end
        
    end
    if delta2_upr-delta2_lwr<dtol;
        conv2=1;
        delta_starL2 = delta2_upr;
        rpL2 = BSL2_u;
    end;
end





