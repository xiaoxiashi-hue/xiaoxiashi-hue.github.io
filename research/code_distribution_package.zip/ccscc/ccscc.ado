capture program drop ccscc
program define ccscc, rclass

version 17
/**********************************************************************************************
ccscc: This is the command implementing "Simple Adaptive Size-Exact Testing for Full-Vector and Subvector Inference in Moment Inequality Models" (Gregory Cox and Xiaoxia Shi, 2021). 
The test compares the quasi-likelihood ratio statistic to a chi-squared critical value, where the degree of freedom is the rank of the inequalities that are active in finite samples. 

Full-vector inference:

Null: B*E[m_i] <= d
Tn = min_{mu:B*mu<=d} n*(B*mbar-d)'*Sigaminv*(B*mbar-d)
Sigmainv = sample variance-covariance of m_i

Subvector inference:

Null: E[B(Z_i)*m_i-C(Z_i)*delta|Z_i] <= d(Z_i)
Tn = min_{mu,delta:B*mu-C*delta<=d} n*(B*mbar-d)'*Sigaminv*(B*mbar-d)
Sigmainv = variance-covariance of m_i conditional on (Z_1,...,Z_n)
***********************************************************************************************/

gettoken z_i 0: 0, match(leftover)
syntax varlist [if] [in] [, ALPHA(real 0.05) MATIneq(string) VECIneq(string) MATNuisa(string) IVDiscrete Refined sigma(string) qpabstol(real 1e-08) qpreltol(real 1e-08) qpfeastol(real 1e-08) bindtol(real 1e-05)]
marksample touse

/**********************************************************************************************
1. User's Input Checking
Syntax: ccscc (Z^(n)) m^(n), B d C alpha IVD R

Inputs:
Z^(n) : Data of instruments, (n x dim(Z))
m^(n) : Data of moments, (n x dim(m))
B     : Matrix multiplied in front of the parameter of interest, (dim(m) x dim(theta))
d     : Vector that appears in the RHS of Hypothesis, (dim(m) x 1)
C     : Matrix multiplied in front of nuisance parameter delta, (dim(m) x dim(delta))
alpha : Numerical scalar between 0 and 1, test size
IVD   : To specify that the instrument is discrete random variable
R     : Refined test, just for the full vector inference

* Either "C" or "C^(n)" should be specified for subvector inference. Otherwise, return error.
***********************************************************************************************/

// Check if user added options
if "`refined'" == ""{
	local Use_RCC 0 
} 
else{
	local Use_RCC 1 
}
if "`ivdiscrete'" == ""{
	local Z_discrete 0 
} 
else{
	local Z_discrete 1 
}
// Check if user added instrument
if "`z_i'"!="" {
	local Use_Z 1
}
else{
	local Use_Z 0
}
// Check if user added matrix premultiplied by delta
if "`matnuisa'"!=""{
	local Use_C 1
}
else{
	local Use_C 0
	//display "No input for matrix multiplied before nuisance parameter"
}
// Check if Sigma is supplied
if "`sigma'"!=""{
	local Use_Sigma 1
}
else{
	local Use_Sigma 0
}
if `Use_C'==0 & `Use_Z'==0 { 
	local fullvector 1
	if `Z_discrete'==1 {
		display "Warning: 'IVDiscrete' is not an argument used in full-vector inference."
	}
}
else if `Use_C'==1 { 
	local fullvector 0
	if `Use_RCC'==1 {
		display "Warning: 'Refined' is not available in subvector inference."
	}
	if `Use_Z'==0 { 
		display as error "ERROR: instrument is not specified while the matrix 'C' is specified."
		exit 110
	}	
}
else{
	display as error "ERROR: instrument is specified while the matrix 'C' is not specified."
	exit 110
}

tempname n mbar Sigmainv t_stat cv rank reject pval P q muhat BC mudeltahat obj C B d stabstol streltol stfeastol

scalar `stabstol' = `qpabstol'
scalar `streltol' = `qpreltol'
scalar `stfeastol' = `qpfeastol'

/**********************************************************************************************
Local variables:

1. Used in Python Quadratic Programming: P, q, BC, muhat, mudeltahat, t_stat, obj
- "P", "q" are QP coefficients
- "BC" are inequality constraints for subvector inference
- "muhat" is QP solution for full-vector inference
- "mudeltahat" is QP solution for subvector inference
- "t_stat" is QP objective, "obj" is temporary variable used to compute QP objective (allow matrix algebra)

2. Result: cv, rank, reject (,t_stat)
- "cv" is critical value for test
- "rank" is for obtaining critical value, degree of freedom for Chi-square distribution.
- "reject" is 1 if the test result is rejection

3. Moments: mbar, Sigmainv
- "mbar" is sample average of moments
- "Sigmainv" is an inverse of the (conditional) var-cov matrix of moments

4. Misc: C, n
- "n" is sample size
- "C" is the matrix multiplied before delta (for subvector inference), which is either explicitly specified by users or computed from data
***********************************************************************************************/


// 1. Full vector inference (When "C" and "Z" are not provided)

if `fullvector'==1 { 
	// Preliminary calculations of moments
	mata: prelim_full_calc("`varlist'", "`touse'", "`P'", "`q'", "`mbar'", "`muhat'", "`Sigmainv'", "`n'", `Use_Sigma', "`sigma'", "`matineq'", "`vecineq'", "`B'", "`d'")

	// Quadratic optimization
	python: doqp("`P'","`q'","`B'","`d'","`muhat'","`stabstol'","`streltol'","`stfeastol'")
	matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
	scalar `t_stat' = `obj'[1,1]
	
	// compute CC critical-value
	mata: cc_calculation("`varlist'", "`touse'", "`B'", "`d'", `Use_RCC', `alpha', "`t_stat'", "`muhat'", "`reject'", "`cv'", "`rank'", "`pval'", `bindtol')
	
	// Return results
	return clear 
	return local title = "Conditional Moment Inequalities Test : Full-vector inference"
	return local cmd = "ccscc"
	return scalar N        = `n'
	return scalar alpha    = `alpha'
	return scalar reject   = `reject'
	return scalar rank     = `rank'
	return scalar cv       = `cv'
	return scalar t_stat  = `t_stat'
	return scalar pval     = `pval'
	return matrix Sigmainv = `Sigmainv'
	return matrix mbar     = `mbar'

	// Display outputs 
	display as text _newline "Number of obs : " `n'
	if `Use_RCC' == 1{
		display "Method : RCC" 
	} 
	else{
		display "Method : CC" 
	}
	if `reject' == 1 {
		display "Reject the hypothesis"
	}
	else{
		display "Accept the hypothesis"
	}
	display "test statistic : " `t_stat'
	display "critical value : " `cv'
	display "rank           : " `rank'
	display "p-value        : " `pval'
	
	
}

// 2. Sub-vector inference
else{
	// Preliminary calculations of moments
	mata: prelim_sub_calc("`z_i'", `Z_discrete', "`C'", "`varlist'", "`touse'", "`matnuisa'", "`BC'", "`P'", "`q'", "`mbar'", "`mudeltahat'", "`Sigmainv'", "`n'", `Use_Sigma', "`sigma'", "`matineq'", "`vecineq'", "`B'", "`d'")
	
	//Quadratic optimization
	python: doqp("`P'","`q'","`BC'","`d'","`mudeltahat'","`stabstol'","`streltol'","`stfeastol'")
	matrix `muhat' = `mudeltahat'[1..colsof(`B'),1]
	matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
	scalar `t_stat' = `obj'[1,1]
	
	// compute sCC critical-value
	mata: subcc_calculation("`B'", "`C'", "`d'", `alpha', "`t_stat'", "`mudeltahat'", "`reject'", "`cv'", "`rank'", "`pval'", `bindtol')
	
	// return list 
	return clear 
	return local title = "Conditional Moment Inequalities Test : Subvector inference"
	return local cmd = "ccscc"
	return scalar N = `n'
	return scalar alpha = `alpha'
	return scalar reject = `reject'
	return scalar rank   = `rank'
	return scalar cv     = `cv'
	return scalar t_stat= `t_stat'
	return scalar pval     = `pval'
	return matrix Sigmainv = `Sigmainv'
	return matrix mbar     = `mbar'


	// Display outputs 
	display as text _newline "Number of obs : " `n'
	display "Method : sCC" 
	if `reject' == 1 {
		display "Reject the hypothesis"
	}
	else{
		display "Accept the hypothesis"
	}
	display "test statistic : " `t_stat'
	display "critical value : " `cv'
	display "rank           : " `rank'
	display "p-value        : " `pval'
	
}
end                  

/*****************************************************************************************
Python Quadratic Optimization by CVXOPT
*****************************************************************************************/

python:

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE" 
from cvxopt import matrix, solvers
from sfi import Matrix, Scalar
solvers.options['show_progress'] = False


def doqp(P, q, G, h, muhat, streltol, stabstol, stfeastol):
	
	solvers.options['show_progress'] = False
	solvers.options['reltol'] = Scalar.getValue(streltol)
	solvers.options['abstol'] = Scalar.getValue(stabstol)
	solvers.options['feastol'] = Scalar.getValue(stfeastol)
	
	P_py = matrix(Matrix.get(P)).trans()
	q_py = matrix(Matrix.get(q)).trans()
	G_py = matrix(Matrix.get(G)).trans()
	h_py = matrix(Matrix.get(h)).trans()
		
	sol=solvers.qp(P_py, q_py, G_py, h_py)
	Matrix.store(muhat,sol['x'])
end


/*****************************************************************************************
MATA function
*****************************************************************************************/
mata: mata clear

mata:
void prelim_full_calc(string vector mname, string scalar touse,
                      string scalar Pname, string scalar qname,
					  string scalar mbarname, string scalar muhatname, 
					  string scalar Sigmainvname, string scalar nname,
					  real scalar Use_Sigma, string scalar Sigmaname,
					  string scalar matineq, string scalar vecineq,
					  string scalar Bname, string scalar dname){
	
	Moment = st_data(., mname, touse)
	n = length(Moment[.,1])
	dm = length(Moment[1,.])
	mbar = mean(Moment)'
	
	if(matineq==""){
		B = I(dm)
	}
	else{
		B = st_matrix(matineq)
	}
	if(vecineq==""){
		d = J(dm,1,0)
	}
	else{
		d = st_matrix(vecineq)
	}
	
	if(Use_Sigma == 0){
		Sigma = variance(Moment)
	}
	else{
		Sigma = st_matrix(Sigmaname)
	}
	Sigma_inverse = luinv(Sigma)
	Sigma_inverse = (Sigma_inverse+Sigma_inverse') / 2
	
	P = 2*Sigma_inverse
	q = -Sigma_inverse*mbar*2
	muhat = J(dm, 1, 0)
	
	st_numscalar(nname,n)
	st_matrix(Pname,P)
	st_matrix(qname,q)
	st_matrix(mbarname,mbar)
	st_matrix(muhatname,muhat)
	st_matrix(Sigmainvname,Sigma_inverse)
	st_matrix(Bname,B)
	st_matrix(dname,d)
}
void prelim_sub_calc(string vector zname, real scalar Z_discrete,
                     string scalar Cmatname, string vector mname, 
					 string scalar touse, string scalar matnuisa, 
					 string scalar BCname, string scalar Pname, 
					 string scalar qname, string scalar mbarname,
					 string scalar mudeltahatname, string scalar Sigmainvname, 
					 string scalar nname, real scalar Use_Sigma, 
					 string scalar Sigmaname,
					 string scalar matineq, string scalar vecineq,
					 string scalar Bname, string scalar dname){
	
	Moment = st_data(., mname, touse)
	n = length(Moment[.,1])
	dm = length(Moment[1,.])
	
	if(matineq==""){
		B = I(dm)
	}
	else{
		B = st_matrix(matineq)
	}
	if(vecineq==""){
		d = J(dm,1,0)
	}
	else{
		d = st_matrix(vecineq)
	}
	
	mbar = mean(Moment)'
	
	C = st_matrix(matnuisa)
	p = length(C[1,.])
	BC = B,-C
	
	// Get Sigmainv using Z
	if(Use_Sigma == 1){
		Sigma = st_matrix(Sigmaname)
	}
	else{
		if(zname==""){
			Sigma = variance(Moment)
		}
		else{
			IV = st_data(.,zname,touse)
			if(Z_discrete==0){
				Sigma = getSigma_continuous(Moment, IV)
			}
			else{
				Sigma = getSigma_discrete(Moment, IV)
			}
		}
	}
	Sigma_inverse = luinv(Sigma)
	Sigma_inverse = (Sigma_inverse+Sigma_inverse') / 2
	
	P = (2*Sigma_inverse, J(dm,p,0) \ J(p,dm+p,0))
	q = -2*(Sigma_inverse,J(dm,p,0) \ J(p,dm+p,0))*(mbar\J(p,1,0))
	mudeltahat = J(dm+p,1,0)
	
	st_numscalar(nname,n)
	st_matrix(Pname,P)
	st_matrix(qname,q)
	st_matrix(Cmatname,C)
	st_matrix(BCname,BC)
	st_matrix(mbarname,mbar)
	st_matrix(mudeltahatname,mudeltahat)
	st_matrix(Sigmainvname,Sigma_inverse)
	st_matrix(Bname,B)
	st_matrix(dname,d)
}

real matrix repmat(real matrix T, real scalar n){
    results = T
    for(i=1; i <= n; i++){
        if(i == 1){
	        results = T
	    }
	    else{
	        results = (results \ T)
	    }
    }
    return (results)
}

real matrix getSigma_discrete(real matrix m_i, real matrix z_i){
	
	n = length(m_i[.,1])
	k = length(m_i[1,.])
	dz = length(z_i[1,.])
	
	uniqueZ = uniqrows(z_i)
	L = length(uniqueZ[.,1]) //number of unique values of Z
	condV = J(k, k, 0)
	
	for(i=1; i<=L; i++){
		m_tmp = select(m_i,rowsum(z_i:==repmat(uniqueZ[i,.],n)):==dz)
		n_tmp = colsum(rowsum(z_i:==repmat(uniqueZ[i,.],n)):==dz)
		condV = condV+(n_tmp/n)*variance(m_tmp)
	}
	return (condV)
}

real matrix getSigma_continuous(real matrix m_i, real matrix z_i){
	n = length(m_i[.,1])
	k = length(m_i[1,.])
	
	sigma0 = variance(z_i)
	sigma0inv = luinv(sigma0)
	sigma0inv = (sigma0inv+sigma0inv')/2
	condV = J(k, k, 0)
	
	index = .
	w = .
	
	for(i=1; i<=n; i++){
		m0 = m_i[i,.]
		z0 = z_i[i,.]
		z_diff = select(z_i-repmat(z0,n),(1::n):!=i)
		vals = diagonal(z_diff*sigma0inv*z_diff')
		minindex(vals, 1, index, w)
		if(w[1,2]!=1){
			rng = runiform(1,rows(index))
			minindex(rng, 1, index, w)
			ix = index[1]
		}
		else{
			ix = index[1]
		}
		m_diff = (m0-select(m_i,(1::n):!=i)[ix,.])
		condV = condV+(m_diff')*(m_diff)/(2*n)
	}
	return (condV)
}


void cc_calculation(string vector mname, string scalar touse,
                    string scalar Bname, string scalar dname,
					real scalar Use_RCC, real scalar alpha, 
					string scalar t_statname, string scalar muhatname, 
					string scalar rejectname, string scalar cvname,
					string scalar rankname, string scalar pvalname,
					real scalar tol){

	ineq_tolerance = -tol
	count_active = 0
	
	B = st_matrix(Bname) 
	d = st_matrix(dname)
	t_stat = st_numscalar(t_statname)
	muhat = st_matrix(muhatname)
	
	// CC
	for(i=1; i<=length(d);i++){
		if( (B*muhat)[i] - d[i] >= ineq_tolerance ){
			count_active = count_active + 1
			if(count_active==1){
				B_active = B[i,.]
				d_active = d[i,.]
			}
			else{
				B_active = (B_active \ B[i,.])
				d_active = (d_active \ d[i,.])
			}
		}
	}
	
	if(count_active > 0){
		rhat = rank(B_active)
		cv_cc = invchi2(rhat,(1-alpha))
		reject_cc = t_stat > cv_cc
		pval = 1-chi2(rhat,t_stat)
	}
	else{
		rhat       = 0
		cv_cc      = 0
		reject_cc  = 0
		t_stat    = 0
		pval       = 1
	}

	// RCC
	if(Use_RCC==0){
		st_numscalar(rankname, rhat)
		st_numscalar(cvname, cv_cc)
		st_numscalar(rejectname, reject_cc)
		st_numscalar(pvalname, pval)
		st_numscalar(t_statname, t_stat)
	}
	else{
		if(rhat == 1){
			Moment = st_data(.,mname,touse)
			n = length(Moment[.,1])
			Sigma = variance(Moment)
			Sigma_sqrt = matpowersym(Sigma, 0.5)
			normB = sqrt(rowsum((B_active*Sigma_sqrt):^2))
			
			index = .
			w = .
			maxindex(normB, 1, index, w)
			
			b1 = B_active[index[1],.]'
			b1norm = sqrt(b1'*Sigma*b1)
			tau = J(length(B[.,1]),1,.)	
			
			for(j=1; j<=length(B[.,1]); j++){
				bjnorm = sqrt(B[j,.]*Sigma*B[j,.]')
				bjb1 = B[j,.]*Sigma*b1
				if(b1norm*bjnorm-bjb1 > tol*b1norm*bjnorm){
					tau[j,1] = b1norm*sqrt(n)*(d[j,1]-B[j,.]*muhat)/(b1norm*bjnorm-bjb1)
				}
				else{
					tau[j,1]= 10^10 // Infinity
				}
			}
			
			minindex(tau, 1, index, w)
			beta = 2*alpha*normal(tau[index[1],1])
			
			cv_rcc = invchi2(rhat,(1-beta))
			reject_rcc = t_stat > cv_rcc
			pval = (1-chi2(rhat,t_stat))/(2*normal(tau[index[1],1]))
		}
		else{
			reject_rcc = reject_cc
			cv_rcc = cv_cc
		}
		st_numscalar(rankname, rhat)
		st_numscalar(cvname, cv_rcc)
		st_numscalar(rejectname, reject_rcc)
		st_numscalar(pvalname, pval)
		st_numscalar(t_statname, t_stat)
	}
	
}

void subcc_calculation(string scalar Bname, string scalar Cmatname,
					   string scalar dname, real scalar alpha, 
					   string scalar t_statname, string scalar mudeltahatname, 
					   string scalar rejectname, string scalar cvname,
					   string scalar rankname, string scalar pvalname,
					   real scalar tol){
					   
	ineq_tolerance=-tol
	count_active = 0
	
	B = st_matrix(Bname) 
	C = st_matrix(Cmatname) 
	d = st_matrix(dname)
	t_stat = st_numscalar(t_statname)
	mudeltahat = st_matrix(mudeltahatname)
	
	dm = length(B[1,.])
	p = length(C[1,.])
	
	muhat = mudeltahat[(1::(dm)),.]
	deltahat = mudeltahat[((dm+1)::(dm+p)),.]
	
	for(i=1; i<=length(d); i++){
		if( (B*muhat)[i] - (C*deltahat)[i] - d[i] >= ineq_tolerance ){
			count_active = count_active + 1
			if(count_active==1){
				B_active = B[i,.]
				C_active = C[i,.]
				d_active = d[i,.]
			}
			else{
				B_active = (B_active \ B[i,.])
				C_active = (C_active \ C[i,.])
				d_active = (d_active \ d[i,.])
			}
		}
	}
	if(count_active > 0){
		rhat = rank((B_active, C_active)) - rank(C_active)
		cv_scc = invchi2(rhat,(1-alpha))
		reject_scc = t_stat > cv_scc
		pval = 1-chi2(rhat,t_stat)
    }
	else{
		reject_scc  = 0
		rhat        = 0
		cv_scc      = 0
		t_stat     = 0
		pval        = 1
	}
	st_numscalar(rankname, rhat)
	st_numscalar(cvname, cv_scc)
	st_numscalar(rejectname, reject_scc)
	st_numscalar(pvalname, pval)
	st_numscalar(t_statname, t_stat)
}

end
