------------------------------------------------------------------------------

Package name:  Article tag (Stata Press to add)

DOI:  Digital object identifier (Stata Press to add)

Title:  Stata Commands for Full-vector and Subvector Inference in Moment Inequality Models

Author 1 name:  Woosik Gong
Author 1 from:  Department of Economics, University of Wisconsin at Madison, Madison, WI
Author 1 email: wgong28@wisc.edu

Author 2 name: Gregory Cox
Author 2 from:  Department of Economics, National University of Singapore, Singapore
Author 2 email: ecsgfc@nus.edu.sg

Author 3 name:  Xiaoxia Shi
Author 3 from:  Department of Economics, University of Wisconsin at Madison, Madison, WI
Author 3 email: xshi@ssc.wisc.edu

Help keywords:  "ccscc" "sccintreg"

File list: ccscc.ado sccintreg.ado ccscc.sthlp sccintreg.sthlp examples.do example_simple.do dataex1.dta dataex2.dta dataex3.dta

Notes: It requires installing Python and its CVXOPT library. Instruction for the installation is provided in the appendix of Article tag (Stata Press to add).