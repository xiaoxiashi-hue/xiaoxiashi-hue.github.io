cscript
capture log close
version 19

log using examples.log, replace

// Example 1: Full-vector inference

use dataex1

matrix A = (1, 0 \ 0, 1) 
matrix b = (0 \ 0)

// Testing H0 : theta=(0,0)
generate m1 = Z1-0
generate m2 = Z2-0
ccscc () m1 m2, matineq(A) vecineq(b)

// Testing H0 : theta=(0,0) with user's choice of sigma
matrix S = I(2) // 2 by 2 identity matrix
ccscc () m1 m2, matineq(A) vecineq(b) sigma(S)

// Refined CC test at theta=(0,0)
ccscc () m1 m2, matineq(A) vecineq(b) r

// H0 : theta=(1,-1)
replace m1 = Z1-(1)
replace m2 = Z2-(-1)
ccscc () m1 m2, matineq(A) vecineq(b)

// H0 : theta=(1,1)
replace m1 = Z1-(1)
replace m2 = Z2-(1)
ccscc () m1 m2, matineq(A) vecineq(b)









// Example 2: subvector inference via ccscc
clear all
set more off



use dataex2
// Summary of continuous variables X1 and X2
summarize X1 X2

// Generate I(X), instrument function
generate iv1 = 1*(X1<=0.5) & (X2<=0.5)
generate iv2 = 1*(X1<=0.5) & (X2>0.5)
generate iv3 = 1*(X1>0.5) & (X2<=0.5)
generate iv4 = 1*(X1>0.5) & (X2>0.5)

// Generate (I(X)',-I(X)')'*(1,X2), which are 8 x 2 matrix. 
// Sample average of it becomes the matrix Cz,
// which is multiplied before nuisance parameter in the moment inequality
generate c11 = iv1
generate c21 = iv2
generate c31 = iv3
generate c41 = iv4
generate c51 = -iv1
generate c61 = -iv2
generate c71 = -iv3
generate c81 = -iv4
generate c12 = iv1*X2
generate c22 = iv2*X2
generate c32 = iv3*X2
generate c42 = iv4*X2
generate c52 = -iv1*X2
generate c62 = -iv2*X2
generate c72 = -iv3*X2
generate c82 = -iv4*X2

// Compute Cz using the data we generated above
matrix C = J(8,2,.)
qui mean c11 c12 c21 c22 c31 c32 c41 c42 c51 c52 c61 c62 c71 c72 c81 c82
matrix meanC = r(table)[1,1..16]

forvalues i = 1/8{
	forvalues j = 1/2{
		matrix C[`i',`j'] = meanC[1,2*(`i'-1)+`j']
	}
}

// Generate (I(X)'*X1,-I(X)'*X1)'
generate zv1 = iv1*X1
generate zv2 = iv2*X1
generate zv3 = iv3*X1
generate zv4 = iv4*X1
generate zv5 = -iv1*X1
generate zv6 = -iv2*X1
generate zv7 = -iv3*X1
generate zv8 = -iv4*X1

// Generate (I(X)'*Yl,-I(X)'*Yu)'
generate zy1 = iv1*Yl
generate zy2 = iv2*Yl
generate zy3 = iv3*Yl
generate zy4 = iv4*Yl
generate zy5 = -iv1*Yu
generate zy6 = -iv2*Yu
generate zy7 = -iv3*Yu
generate zy8 = -iv4*Yu

// Generate (I(X)'*(Yl-(-1)*X1),-I(X)'*(Yu-(-1)*X1))'
// Its moment is used to test H0: beta1 = (-1)
generate m1 = zy1 - (-1)*zv1
generate m2 = zy2 - (-1)*zv2
generate m3 = zy3 - (-1)*zv3
generate m4 = zy4 - (-1)*zv4
generate m5 = zy5 - (-1)*zv5
generate m6 = zy6 - (-1)*zv6
generate m7 = zy7 - (-1)*zv7
generate m8 = zy8 - (-1)*zv8

matrix dz = J(8,1,0)
matrix B = I(8)
	
ccscc (X1 X2) m1 m2 m3 m4 m5 m6 m7 m8, matineq(B) matnuisa(C) vecineq(dz)

clear
use dataex3
// Summary of discrete variables X1 and X2
summarize i.X1 i.X2

generate iv1 = 1*(X1==0) & (X2==0)
generate iv2 = 1*(X1==0) & (X2==1)
generate iv3 = 1*(X1==1) & (X2==0)
generate iv4 = 1*(X1==1) & (X2==1)
	
generate c11 = iv1
generate c21 = iv2
generate c31 = iv3
generate c41 = iv4
generate c51 = -iv1
generate c61 = -iv2
generate c71 = -iv3
generate c81 = -iv4
generate c12 = iv1*X2
generate c22 = iv2*X2
generate c32 = iv3*X2
generate c42 = iv4*X2
generate c52 = -iv1*X2
generate c62 = -iv2*X2
generate c72 = -iv3*X2
generate c82 = -iv4*X2

matrix C = J(8,2,.)
qui mean c11 c12 c21 c22 c31 c32 c41 c42 c51 c52 c61 c62 c71 c72 c81 c82
matrix meanC = r(table)[1,1..16]

forvalues i = 1/8{
	forvalues j = 1/2{
		matrix C[`i',`j'] = meanC[1,2*(`i'-1)+`j']
	}
}

generate zv1 = iv1*X1
generate zv2 = iv2*X1
generate zv3 = iv3*X1
generate zv4 = iv4*X1
generate zv5 = -iv1*X1
generate zv6 = -iv2*X1
generate zv7 = -iv3*X1
generate zv8 = -iv4*X1

generate zy1 = iv1*Yl
generate zy2 = iv2*Yl
generate zy3 = iv3*Yl
generate zy4 = iv4*Yl
generate zy5 = -iv1*Yu
generate zy6 = -iv2*Yu
generate zy7 = -iv3*Yu
generate zy8 = -iv4*Yu

generate m1 = zy1 - (-1)*zv1
generate m2 = zy2 - (-1)*zv2
generate m3 = zy3 - (-1)*zv3
generate m4 = zy4 - (-1)*zv4
generate m5 = zy5 - (-1)*zv5
generate m6 = zy6 - (-1)*zv6
generate m7 = zy7 - (-1)*zv7
generate m8 = zy8 - (-1)*zv8

matrix dz = J(8,1,0)
matrix B = I(8)

ccscc (X1 X2) m1 m2 m3 m4 m5 m6 m7 m8, matineq(B) matnuisa(C) vecineq(dz) ivd

// Construct CS using test inversion

matrix grid = J(41,1,0)
matrix rejects = J(41,1,0)
matrix tstats = J(41,1,0)
matrix cvs = J(41,1,0)

forvalues j = 1/41{
	matrix grid[`j',1] = 0.05*(`j'-1)-2
}

forvalues j = 1/41{
	qui replace m1 = zy1 - grid[`j',1]*zv1
	qui replace m2 = zy2 - grid[`j',1]*zv2
	qui replace m3 = zy3 - grid[`j',1]*zv3
	qui replace m4 = zy4 - grid[`j',1]*zv4
	qui replace m5 = zy5 - grid[`j',1]*zv5
	qui replace m6 = zy6 - grid[`j',1]*zv6
	qui replace m7 = zy7 - grid[`j',1]*zv7
	qui replace m8 = zy8 - grid[`j',1]*zv8
	
	qui ccscc (X1 X2) m1 m2 m3 m4 m5 m6 m7 m8, matineq(B) matnuisa(C) vecineq(dz) ivd
	
	matrix rejects[`j',1] = `r(reject)'
	matrix tstats[`j',1] = `r(t_stat)'
	matrix cvs[`j',1] = `r(cv)'
}

svmat grid
svmat tstats
svmat cvs

// Plot test statistics and critical values over the grid
line tstats grid, legend(order(1 "Test statistics" 2 "Critical values")) xtitle("") ///
|| line cvs grid 











// Example 3: subvector inference via sccintreg
clear all
set more off

use dataex2 // Use continuous X dataset

sccintreg Yl Yu X1 X2

use dataex2 // Use continuous X dataset

sccintreg Yl Yu X1 X2, subset("cons X1")

clear
use dataex3 // Use discrete X dataset
sccintreg Yl Yu X1 X2, d

// Use grid search for the coefficient of "X1"
// Grid is from -2 to 0 and has 201 points.
matrix lbound = (-2)
matrix ubound = (0)
sccintreg Yl Yu X1 X2, d lb(lbound) ub(ubound) subset("X1") grid(201)
matrix grid = r(GRIDs)[1,1..201]'
matrix Tns = r(Tns)[1,1..201]'
matrix CVs = r(CVs)[1,1..201]'


svmat grid
svmat Tns
svmat CVs

// Plot test statistics and critical values over the grid
line Tns grid, legend(order(1 "Test statistics" 2 "Critical values")) xtitle("") ///
|| line CVs grid



log close