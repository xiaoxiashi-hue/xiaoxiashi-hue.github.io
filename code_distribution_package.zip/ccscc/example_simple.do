cscript
capture log close

log using example_simple.log, replace


pwd
cscript

*** code from refere **********************
python search

use dataex1.dta , clear
generate m1 = Z1 - 0
generate m2 = Z2 - 0
matrix B = (1, 0 \ 0, 1)
matrix d = (0 \ 0)
ccscc () m1 m2, matineq(B) vecineq(d)

*************************
log close