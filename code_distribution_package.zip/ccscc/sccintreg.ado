capture program drop sccintreg
program define sccintreg, rclass

version 17



syntax varlist [if] [in] [, ALPHA(real 0.05) INSTrument(varlist) subset(string) Discrete NOCONStant sigma(string) UB(string) LB(string) relstep(real 0.1) PRECision(real 1e-08) qpabstol(real 1e-08) qpreltol(real 1e-08) qpfeastol(real 1e-08) bindtol(real 1e-05) GRIDsearch(integer 1)]
marksample touse

gettoken Y_L varlist: varlist
gettoken Y_U varlist: varlist


tempname n dx dsubset subsetix ci_results test_results tstats cvs grid ubs lbs P0 q0 A0 b0 sol0 Sigmainv ZX ZY P q A b sol muhat mbar obj t_stats cv theta theta_l theta_m theta_u reject stabstol streltol stfeastol

scalar `stabstol' = `qpabstol'
scalar `streltol' = `qpreltol'
scalar `stfeastol' = `qpfeastol'

// Check if user added options

if "`instrument'"==""{
	local Use_IV 0
}
else{
	local Use_IV 1
}

if "`discrete'"==""{
	local Discrete 0
}
else{
	local Discrete 1
}

if "`sigma'"!=""{
	local Use_Sigma 1
}
else{
	local Use_Sigma 0
}

if "`noconstant'"!=""{
	local Use_cons 0
}
else{
	local Use_cons 1
}

mata: st_numscalar("`dx'",length(st_data(., "`varlist'", "`touse'")[1,.]))
local dx = `dx'

if "`subset'" == ""{
	local Use_subset = 0
	matrix `subsetix' = J(`dx',1,1)
	if `Use_cons'==0{
		local Report_cons 0
	}
	else{
		local Report_cons 1
	}
	
}
else{
	local Use_subset = 1
	matrix `subsetix' = J(`dx',1,0)	
	local iter = 0
	local Report_cons 0
	foreach vfull of varlist `varlist'{
		local iter = `iter' + 1
		foreach vsub in `subset'{
			if "`vfull'"=="`vsub'"{
				matrix `subsetix'[`iter',1] = 1
			}
			else if "`vsub'"=="cons"{
				local Report_cons 1
			}
		}
	}
}

local subsetlist ""
if `Report_cons' == 1 {
	local subsetlist = "`subsetlist'" + "cons"
}
local iter = 0
foreach vfull of varlist `varlist'{
	local iter = `iter' + 1
	if `subsetix'[`iter',1] == 1 {
		local subsetlist = "`subsetlist'" + " `vfull'"
	}
}
if "`subset'" != ""{
	display "Calculate CIs for ( `subsetlist' )"
}

if `Use_cons' == 0 & `Report_cons' == 1{
	display as error "ERROR: The NOCONSTANT option is specified while 'subset' is including the constant. Either remove the NOCONSTANT option or exclude 'cons' from 'subset'."
	exit 110
}

mata: st_numscalar("`dsubset'",sum(st_matrix("`subsetix'")))
if `dsubset'+`Report_cons'==0{
	display as error "ERROR: subset of X is not well defined"
	exit 110
}

if `gridsearch' == 1 {
	local Use_grid 0 
	matrix `ci_results' = J(`dsubset'+`Report_cons', 2, 0)
} 
else{
	local Use_grid 1 
	matrix `ci_results' = J(`dsubset'+`Report_cons', 2, 0)
	matrix `test_results' = J(`dsubset'+`Report_cons', `gridsearch', 0)
	matrix `grid' = J(`dsubset'+`Report_cons', `gridsearch', 0)
	matrix `tstats' = J(`dsubset'+`Report_cons', `gridsearch', 0)
	matrix `cvs' = J(`dsubset'+`Report_cons', `gridsearch', 0)
}

if "`ub'"=="" & "`lb'"=="" & `Use_grid'==0 {
	matrix `lbs' = J(`dsubset'+`Report_cons',1,-100)
	matrix `ubs' = J(`dsubset'+`Report_cons',1, 100)
}
else if "`ub'"!="" & "`lb'"!="" {
	matrix `lbs' = `lb''
	matrix `ubs' = `ub''
	
	display "Bounds are set"
	local iter = 0
	foreach vsub in `subsetlist'{
		local iter = `iter' + 1
		display as text "`vsub'     : ["  `lbs'[`iter',1]  ", "  `ubs'[`iter',1]  "]"
	}
}
else if "`ub'"=="" & "`lb'"=="" & `Use_grid'==1 {
	display as error "ERROR: Upper and lower bounds are neccesary for grid search" 
	exit 110
}
else if "`ub'"=="" & "`lb'"!="" {
	display as error "ERROR: only upper bounds specified but not lower bounds" 
	exit 110
}
else if "`ub'"!="" & "`lb'"=="" {
	display as error "ERROR: only lower bounds specified but not upper bounds" 
	exit 110
}

if rowsof(`lbs')!=`dsubset'+`Report_cons' | rowsof(`ubs')!=`dsubset'+`Report_cons'{
	display as error "ERROR: the dimension of lower/upper bound is wrong"
	exit 110
}




// Construct CI for each coefficient

// Bisection algorithm

if `Use_grid'==0 {
	// Initial estimator by GMM

	mata: prelim_calc1("`Y_L'", "`Y_U'", "`varlist'", "`instrument'", "`touse'", "`P0'", "`q0'", "`A0'", "`b0'", "`sol0'", `Discrete', "`Sigmainv'", "`ZX'", "`ZY'", "`n'", `Use_Sigma', "`sigma'", `Use_cons')
	python: doqp("`P0'","`q0'","`A0'","`b0'","`sol0'","`stabstol'","`streltol'","`stfeastol'") // get initial estimator

	if `Report_cons' == 1 {
		scalar `theta' = `sol0'[1,1]
		scalar `reject' = 0
		
		if `theta' >= `ubs'[1,1] | `theta' <= `lbs'[1,1]{
			display "WARNING: estimated intercept (" `theta' ") does not lie in the bound. Initial point is set to the middle point of the parameter set"
			scalar `theta' = (`ubs'[1,1]+`lbs'[1,1])/2
		}
		
		mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")
		
		python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
		matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
		matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
		scalar `t_stats' = `obj'[1,1]
			
		mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol') // Run subvector test
		
		
			
		local iter = 1	
		local ssize_u = 0.1*`relstep'*(`ubs'[1,1] - `theta')
		local ssize_l = 0.1*`relstep'*(`theta' - `lbs'[1,1])
		
		scalar `theta_u' = `theta' + `ssize_u'
		scalar `theta_l' = `theta' - `ssize_l'
		
		while `reject'==1 & `iter' < 10/`relstep' { 
			mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_u'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

			python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'")
				
			matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
			matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
			scalar `t_stats' = `obj'[1,1]
				
			mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol') // Run subvector test
			if `reject'==0 {
				scalar `theta' = `theta_u'
				continue, break
			}
			
			mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_l'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

			python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'")
				
			matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
			matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
			scalar `t_stats' = `obj'[1,1]
				
			mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol') // Run subvector test
			if `reject'==0 {
				scalar `theta' = `theta_l'
				continue, break
			}

			scalar `theta_u' = `theta_u' + `ssize_u'
			scalar `theta_l' = `theta_l' - `ssize_l'
			local iter = `iter' + 1
		}

		if `reject'==1 {
			display as error "ERROR: a feasible value for intercept parameter not found."
			exit 110
		}
		
		// 1. Find lower bound
		local iter = 1
		scalar `theta_l' = `theta'
		local ssize =  `relstep'*(`theta' - `lbs'[1,1])
			
		while `reject' == 0 & `theta_l' > `lbs'[1,1]{
				
			scalar `theta_l' = `theta_l' - `ssize' // Decrease theta by "0.1*(theta0-lb)"
			mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_l'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

			python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic

			matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
			matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
			scalar `t_stats' = `obj'[1,1]
								
			mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
		}
			
		if `theta_l' < `lbs'[1,1]{
			display "WARNING: lower bound is hit during bisection algorithm. You may want the lower bound lower"
			matrix `ci_results'[1,1] = `lbs'[1,1]
		}
		else{
			scalar `theta_u' = `theta_l'+ `ssize' // Upperbound for the low end of CI
			scalar `theta_m' = (`theta_l'+`theta_u')/2 

			local iter = 1
			scalar `reject' = 0

			while `ssize'*(2^(-`iter'+1)) > `precision' {
					
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_m'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
					
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
					
					
				if `reject' == 1{
					scalar `theta_l' = `theta_m'
					scalar `theta_m' = (`theta_l'+`theta_u')/2
				}
				else{
					scalar `theta_u' = `theta_m'
					scalar `theta_m' = (`theta_l'+`theta_u')/2
				}
				local iter = `iter'+1
			}
			matrix `ci_results'[1,1] = `theta_m'
		}
		// 2. Find upper bound
		local iter = 1
		scalar `reject' = 0
		scalar `theta_u' = `theta'
		local ssize =  `relstep'*(`ubs'[1,1]-`theta')
			
		while `reject' == 0 & `theta_u' < `ubs'[1,1]{

			scalar `theta_u' = `theta_u' + `ssize' // Increase theta by "0.1*(ub-theta0)"
			mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_u'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

			python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
			matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
			matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
			scalar `t_stats' = `obj'[1,1]
				
			mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
		}
		if `theta_u' > `ubs'[1,1]{
			di "WARNING: upper bound is hit during bisection algorithm. You may want the upper bound higher"
			matrix `ci_results'[1,2] = `ubs'[1,1]
		}
		else{
			scalar `theta_l' = `theta_u' - `ssize' // Upperbound for the low end of CI
			scalar `theta_m' = (`theta_l'+`theta_u')/2 
				
			local iter = 1
			scalar `reject' = 0
				
			while `ssize'*(2^(-`iter'+1)) > `precision' {
					
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_m'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
					
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
					
				if `reject' == 1{
					scalar `theta_u' = `theta_m'
					scalar `theta_m' = (`theta_l'+`theta_u')/2
				}
				else{
					scalar `theta_l' = `theta_m'
					scalar `theta_m' = (`theta_l'+`theta_u')/2
				}
				local iter = `iter'+1
			}
			matrix `ci_results'[1,2] = `theta_m'
		}

	} // Intercept
	if `Report_cons' == 1 {
		local subiter = 1
	}
	else {
		local subiter = 0
	}

	forvalue xix0 = 1/`dx'{
		if `subsetix'[`xix0',1] == 1 {
			local xix = `xix0'+`Use_cons'
			local subiter = `subiter' + 1
			scalar `theta' = `sol0'[`xix',1]
			scalar `reject' = 0
			
			if `theta' >= `ubs'[`subiter',1] | `theta' <= `lbs'[`subiter',1]{
				display "WARNING: estimated " `xix0' "th variable's coefficient (" `theta' ") does not lie in the bound. Initial point is set to the middle point of the parameter set"
				scalar `theta' = (`ubs'[`subiter',1]+`lbs'[`subiter',1])/2
			}
			mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")
			
			python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
			matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
			matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
			scalar `t_stats' = `obj'[1,1]
			
			mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol') // Run subvector test
			
			
				
			local iter = 1	
			local ssize_u = 0.1*`relstep'*(`ubs'[`subiter',1] - `theta')
			local ssize_l = 0.1*`relstep'*(`theta' - `lbs'[`subiter',1])
			
			scalar `theta_u' = `theta' + `ssize_u'
			scalar `theta_l' = `theta' - `ssize_l'
			
			while `reject'==1 & `iter' < 10/`relstep' { 
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_u'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'")
				
				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
					
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol') // Run subvector test
				if `reject'==0 {
					scalar `theta' = `theta_u'
					continue, break
				}
				
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_l'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'")
					
				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
					
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol') // Run subvector test
				if `reject'==0 {
					scalar `theta' = `theta_l'
					continue, break
				}
			
				scalar `theta_u' = `theta_u' + `ssize_u'
				scalar `theta_l' = `theta_l' - `ssize_l'
				local iter = `iter' + 1
			}
		
			if `reject'==1 {
				display as error "ERROR: a feasible value for " `xix0' "th variable's coefficient parameter not found."
				exit 110
			}
			
			// 1. Find lower bound
			local iter = 1
			scalar `theta_l' = `theta'
			local ssize =  `relstep'*(`theta' - `lbs'[`subiter',1])
			
			while `reject' == 0 & `theta_l' > `lbs'[`subiter',1]{
				
				scalar `theta_l' = `theta_l' - `ssize' // Decrease theta by "0.1*(theta0-lb)"
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_l'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic

				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
								
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
			}
			
			if `theta_l' < `lbs'[`subiter',1]{
				display "WARNING: lower bound is hit during bisection algorithm. You may want the lower bound lower"
				matrix `ci_results'[`subiter',1] = `lbs'[`subiter',1]
			}
			else{
				scalar `theta_u' = `theta_l'+ `ssize' // Upperbound for the low end of CI
				scalar `theta_m' = (`theta_l'+`theta_u')/2 

				local iter = 1
				scalar `reject' = 0

				while `ssize'*(2^(-`iter'+1)) > `precision' {
					
					mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_m'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

					python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
					matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
					matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
					scalar `t_stats' = `obj'[1,1]
					
					mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
					
					
					if `reject' == 1{
						scalar `theta_l' = `theta_m'
						scalar `theta_m' = (`theta_l'+`theta_u')/2
					}
					else{
						scalar `theta_u' = `theta_m'
						scalar `theta_m' = (`theta_l'+`theta_u')/2
					}
					local iter = `iter'+1
				}
				matrix `ci_results'[`subiter',1] = `theta_m'
			}
			// 2. Find upper bound
			local iter = 1
			scalar `reject' = 0
			scalar `theta_u' = `theta'
			local ssize =  `relstep'*(`ubs'[`subiter',1]-`theta')
			
			while `reject' == 0 & `theta_u' < `ubs'[`subiter',1]{

				scalar `theta_u' = `theta_u' + `ssize' // Increase theta by "0.1*(ub-theta0)"
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_u'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
				
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
			}
			if `theta_u' > `ubs'[`subiter',1]{
				di "WARNING: upper bound is hit during bisection algorithm. You may want the upper bound higher"
				matrix `ci_results'[`subiter',2] = `ubs'[`subiter',1]
			}
			else{
				scalar `theta_l' = `theta_u' - `ssize' // Upperbound for the low end of CI
				scalar `theta_m' = (`theta_l'+`theta_u')/2 
				
				local iter = 1
				scalar `reject' = 0
				
				while `ssize'*(2^(-`iter'+1)) > `precision' {
					
					mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_m'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

					python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
					matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
					matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
					scalar `t_stats' = `obj'[1,1]
					
					mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
					
					if `reject' == 1{
						scalar `theta_u' = `theta_m'
						scalar `theta_m' = (`theta_l'+`theta_u')/2
					}
					else{
						scalar `theta_l' = `theta_m'
						scalar `theta_m' = (`theta_l'+`theta_u')/2
					}
					local iter = `iter'+1
				}
				matrix `ci_results'[`subiter',2] = `theta_m'
			}

		} // Subset loop
	} // Exogenous variables loop
} // Bisection
else{ // Grid search
	mata: prelim_calc1("`Y_L'", "`Y_U'", "`varlist'", "`instrument'", "`touse'", "`P0'", "`q0'", "`A0'", "`b0'", "`sol0'", `Discrete', "`Sigmainv'", "`ZX'", "`ZY'", "`n'", `Use_Sigma', "`sigma'", `Use_cons')

	if `Report_cons' == 1 {
		local ssize =  (1/(`gridsearch'-1))*(`ubs'[1,1] - `lbs'[1,1])
		local iter = 1
		while `iter' <= `gridsearch'{
			scalar `theta_m' = `lbs'[1,1] + `ssize'*(`iter'-1)
			matrix `grid'[1,`iter'] = `theta_m'
			
			mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_m'", "`Sigmainv'", "`ZX'", "`ZY'", 1, "`mbar'")

			python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
			matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
			matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
			scalar `t_stats' = `obj'[1,1]
				
			mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
			matrix `test_results'[1,`iter'] = `reject'
			matrix `tstats'[1,`iter'] = `t_stats'
			matrix `cvs'[1,`iter'] = `cv'
			local iter = `iter' + 1
		}
		local lix = 1
		while `test_results'[1,`lix'] == 1{
			local lix = `lix' + 1
		}
		if `lix' == 1 {
			di "WARNING: lower bound is hit during grid search algorithm for intercept. You may want the upper bound higher"
			matrix `ci_results'[1,1] = `grid'[1,`lix']
		}
		else{
			matrix `ci_results'[1,1] = `grid'[1,`lix']-`ssize'
		}
		
		if `lix' == `gridsearch'+1{
			di "WARNING: feasible value for intercept not found. You may want to enlarge the grid"
		}
		
		local uix = `gridsearch'
		while `test_results'[1,`uix'] == 1{
			local uix = `uix' - 1
		}
		
		if `uix' == `gridsearch' {
			di "WARNING: upper bound is hit during grid search algorithm for intercept. You may want the upper bound higher"
			matrix `ci_results'[1,2] = `grid'[1,`uix']
		}
		else{
			matrix `ci_results'[1,2] = `grid'[1,`uix']+`ssize'
		}
		
		
	}
	
	if `Report_cons' == 1 {
		local subiter = 1
	}
	else {
		local subiter = 0
	}

	forvalue xix0 = 1/`dx'{
		if `subsetix'[`xix0',1] == 1 {
			local xix = `xix0'+`Use_cons'
			local subiter = `subiter' + 1

			local ssize =  (1/(`gridsearch'-1))*(`ubs'[`subiter',1] - `lbs'[`subiter',1])
			local iter = 1
			while `iter' <= `gridsearch'{
				scalar `theta_m' = `lbs'[`subiter',1] + `ssize'*(`iter'-1)
				matrix `grid'[`subiter',`iter'] = `theta_m'
				
				mata: prelim_calc2("`P'", "`q'", "`A'", "`b'", "`sol'", "`theta_m'", "`Sigmainv'", "`ZX'", "`ZY'", `xix', "`mbar'")

				python: doqp("`P'","`q'","`A'","`b'","`sol'","`stabstol'","`streltol'","`stfeastol'") // get test statistic
				matrix `muhat' = `sol'[1..colsof(`Sigmainv'),1]
				matrix `obj' = ((`mbar'-`muhat')'*`Sigmainv'*(`mbar'-`muhat')*`n')
				scalar `t_stats' = `obj'[1,1]
				
				mata: sccintreg_calculation("`A'", "`b'", `alpha', "`t_stats'", "`sol'", "`reject'", "`cv'", `bindtol')
				matrix `test_results'[`subiter',`iter'] = `reject'
				matrix `tstats'[`subiter',`iter'] = `t_stats'
				matrix `cvs'[`subiter',`iter'] = `cv'
				local iter = `iter' + 1
			}
			
			local lix = 1
			while `test_results'[`subiter',`lix'] == 1{
				local lix = `lix' + 1
			}
			if `lix' == 1 {
				di "WARNING: lower bound is hit during grid search algorithm for " `xix0' "th variable's coefficient. You may want the upper bound higher"
				matrix `ci_results'[`subiter',1] = `grid'[`subiter',`lix']
			}
			else{
				matrix `ci_results'[`subiter',1] = `grid'[`subiter',`lix']-`ssize'
			}
			
			if `lix' == `gridsearch'+1{
				di "WARNING: feasible value for " `xix0' "th variable's coefficient not found. You may want to enlarge the grid"
			}
			
			local uix = `gridsearch'
			while `test_results'[`subiter',`uix'] == 1{
				local uix = `uix' - 1
			}
			
			if `uix' == `gridsearch' {
				di "WARNING: upper bound is hit during grid search algorithm for " `xix0' "th variable's coefficient. You may want the upper bound higher"
				matrix `ci_results'[`subiter',2] = `grid'[`subiter',`uix']
			}
			else{
				matrix `ci_results'[`subiter',2] = `grid'[`subiter',`uix']+`ssize'
			}
			
			
		} // if Subset
	} // Regressor loop
} // GRIDSEARCH
	

local rownames
local iter = 0

if `Report_cons' == 1 {
	local rownames `rownames' "intercept"
}

foreach i of varlist `varlist'{
	local iter = `iter' + 1
	if `subsetix'[`iter',1]==1{
		local rownames `rownames' `i'
	}
}


// Display table result

collect clear

collect title "Table of confidence intervals"

collect get Variable = "[`:di 100*(1-`alpha')' % Conf.",        tags(Col[1])
collect get Variable = "Interval]",                             tags(Col[2])

if `Report_cons' == 1 {
	collect get constant = "`:di `ci_results'[1,1]'",       tags(Col[1])
	collect get constant = "`:di `ci_results'[1,2]'",       tags(Col[2])
}

local iter = 0
local iter2 = 0
foreach i of varlist `varlist'{
	local iter = `iter' + 1
	if `subsetix'[`iter',1]==1{
		local iter2 = `iter2' + 1
		collect get `i' = "`:di `ci_results'[`iter2'+`Report_cons',1]'",       tags(Col[1])
		collect get `i' = "`:di `ci_results'[`iter2'+`Report_cons',2]'",       tags(Col[2])
	}
}

collect style header Col, level(hide)
collect style cell result[Variable], border(bottom)
collect style cell, sformat("  %s  ")
collect style cell result[Variable], smcl(text)
qui collect layout (result) (Col)

display as text _newline "Number of obs : " `n'
collect preview


local rate = 100*(1-`alpha')

matrix rownames `ci_results' = `rownames'
matrix colnames `ci_results' = "[`rate' % Conf" "Interval]"

// Return result

return clear 
return local title = "Conditional Moment Inequalities Tests for Exogenous Interval Regression"
return local cmd = "sccintreg"
return scalar N = `n'
return scalar alpha = `alpha'
return matrix table = `ci_results'
if `Use_grid' == 1{
	return matrix Tns = `tstats'
	return matrix CVs = `cvs'
	return matrix TESTs = `test_results'
	return matrix GRIDs = `grid'
}


end               


   


/*****************************************************************************************
Python Quadratic Optimization by CVXOPT
*****************************************************************************************/

python:

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE" 
from cvxopt import matrix, solvers
from sfi import Matrix, Scalar

def doqp(P, q, G, h, muhat, streltol, stabstol, stfeastol):
	
	solvers.options['show_progress'] = False
	solvers.options['reltol'] = Scalar.getValue(streltol)
	solvers.options['abstol'] = Scalar.getValue(stabstol)
	solvers.options['feastol'] = Scalar.getValue(stfeastol)
	
	P_py = matrix(Matrix.get(P)).trans()
	q_py = matrix(Matrix.get(q)).trans()
	G_py = matrix(Matrix.get(G)).trans()
	h_py = matrix(Matrix.get(h)).trans()
		
	sol=solvers.qp(P_py, q_py, G_py, h_py)
	Matrix.store(muhat,sol['x'])
end

/*****************************************************************************************
MATA function
*****************************************************************************************/
mata: mata clear

mata:

void prelim_calc1(string vector ylname, string vector yuname,
                 string vector exogname, string vector ivname,
				 string scalar touse,
				 string scalar Pname, string scalar qname, 
				 string scalar Aname, string scalar bname, 
				 string scalar solname, real scalar Discrete,
				 string scalar Wname, string scalar ZXname,
				 string scalar ZYname, string scalar nname,
				 real scalar Use_Sigma, string scalar Sigmaname,
				 real scalar Use_cons){
				 	
	Y_L = st_data(., ylname, touse)
	Y_U = st_data(., yuname, touse)
	
	X = st_data(., exogname, touse)
	
	n = length(X[.,1]) // sample size
		
	p = length(X[1,.]) // Dimension of exogenous regressor
	k = p+Use_cons     // Dimension of theta
	
	if(ivname!=""){
		Z = st_data(., ivname, touse)
		if(min(Z) < 0){
			printf("WARNING: The user input for instrument has negative value. Check if the instrumental value is correctly set.")
		}
	}
	else{
		if(Discrete==0){
			Z = J(n,p,0)
			for(i=1; i <= p; i++){
				if(min(X[.,i])!=median(X[.,i])){
					Z[.,i] = 1*(X[.,i] :>= median(X[.,i]))
				}
				else{
					Z[.,i] = 1*(X[.,i] :> median(X[.,i]))
				}
			}
		}
		else{
			Z = X
		}
		Z = Z_discrete_transform(Z)
	}
	C = makeC(X,Z,Use_cons) 
	
	/* 
	Note that it becomes a "n x (dm*k) matrix". 
	Its column mean (which is row vector) made into "k x dm" matrix rowwisely becomes the transpose of the matrix "Cz" we need
	*/
	Cz = rowshape(mean(C),k)'
	
	dm = length(Z[1,.])*2 // Dimension of moment function
	mt = (repmat(Y_L',dm/2))':*Z,(repmat(-Y_U',dm/2))':*Z
	if(Use_Sigma==1){
		Sigma = st_matrix(Sigmaname)
	}
	else{
		if(Discrete==1){
			Sigma = getSigma_discrete(mt, X)
		}
		else{
			Sigma = getSigma_continuous(mt, X)
		}
	}
	Sigmainv = luinv(Sigma)
	Sigmainv = (Sigmainv+Sigmainv') / 2
	
	P = 2*(Cz, I(dm))'*Sigmainv*(Cz, I(dm))
	q = -2*(Cz, I(dm))'*Sigmainv*mean(mt)'
	A = (J(dm,k,0) , I(dm))
	b = J(dm,1,0)
	sol = J(k+dm,1,0)
		
	st_matrix(Pname,P)
	st_matrix(qname,q)
	st_matrix(Aname,A)
	st_matrix(bname,b)
	st_matrix(solname,sol)
	st_matrix(Wname,Sigmainv)
	st_matrix(ZXname,Cz)
	st_matrix(ZYname,mean(mt)')
	st_numscalar(nname,n)
}

void prelim_calc2(string scalar Pname, string scalar qname, 
				 string scalar Aname, string scalar bname, 
				 string scalar solname, string scalar thetaname,
				 string scalar Wname, string scalar ZXname,
				 string scalar ZYname, real  scalar xix,
				 string scalar mbarname){
				 	
	ZX = st_matrix(ZXname)
	ZY = st_matrix(ZYname)
	Sigmainv = st_matrix(Wname)
	theta = st_numscalar(thetaname)
	
	dm = length(ZY[.,1]) // Dimension of moment function
	p = length(ZX[1,.])-1 // Dimension of nuisance parameter
	
	mbar = ZY - ZX[.,xix]*theta
	C = select(ZX, (1..(p+1)):!=(xix))

	P = (2*Sigmainv, J(dm,p,0) \ J(p,dm+p,0))
	q = -2*(Sigmainv,J(dm,p,0) \ J(p,dm+p,0))*(mbar\J(p,1,0))
	A = (I(dm), -C)
	b =  J(dm,1,0)
	sol = J(dm+p,1,0)
		
	st_matrix(Pname,P)
	st_matrix(qname,q)
	st_matrix(Aname,A)
	st_matrix(bname,b)
	st_matrix(solname,sol)
	st_matrix(mbarname,mbar)
}

real scalar median(real colvector x)
{
    real colvector tmp
    real scalar idx
    
    tmp = sort(x, 1)
    idx = rows(x)*0.5
    
    if (mod(idx, 1)) {
        return(tmp[ceil(idx)])
    }
    else {
        return(((tmp[idx] + tmp[idx + 1])/2))
    }
}


real matrix repmat(real matrix T, real scalar n){
    results = T
    for(i=1; i <= n; i++){
        if(i == 1){
	        results = T
	    }
	    else{
	        results = (results \ T)
	    }
    }
    return (results)
}

real matrix makeC(real matrix X1, real matrix Zt, real scalar Use_cons){
	dx = length(X1[1,.])
	k = length(Zt[1,.])
	
	if (Use_cons == 1){
		C = (Zt),(-Zt)
	
		for(i=1; i<=dx; i++){
			C = (C,(repmat(X1[.,i]',k))':*Zt,(repmat(-X1[.,i]',k))':*Zt)
		}
	}
	else{
		C = (repmat(X1[.,1]',k))':*Zt,(repmat(-X1[.,1]',k))':*Zt
		for(i=2; i<=dx; i++){
			C = (C,(repmat(X1[.,i]',k))':*Zt,(repmat(-X1[.,i]',k))':*Zt)
		}
	}
	

	return(C)
}

real matrix Z_discrete_transform(real matrix z_i){
	
	n = length(z_i[.,1])
	dz = length(z_i[1,.])
	
	uniqueZ = uniqrows(z_i)
	L = length(uniqueZ[.,1]) //number of unique values of Z
	Zt = J(n, L, 0)
	
	for(i=1; i<=L; i++){
		Zt[.,i] = rowsum(z_i:==repmat(uniqueZ[i,.],n)):==dz
	}
	return (Zt)
}

real matrix getSigma_discrete(real matrix m_i, real matrix z_i){
	
	n = length(m_i[.,1])
	k = length(m_i[1,.])
	dz = length(z_i[1,.])
	
	uniqueZ = uniqrows(z_i)
	L = length(uniqueZ[.,1]) //number of unique values of Z
	condV = J(k, k, 0)
	
	for(i=1; i<=L; i++){
		m_tmp = select(m_i,rowsum(z_i:==repmat(uniqueZ[i,.],n)):==dz)
		n_tmp = colsum(rowsum(z_i:==repmat(uniqueZ[i,.],n)):==dz)
		condV = condV+(n_tmp/n)*variance(m_tmp)
	}
	return (condV)
}


real matrix getSigma_continuous(real matrix m_i, real matrix z_i){
	n = length(m_i[.,1])
	k = length(m_i[1,.])
	
	sigma0 = variance(z_i)
	sigma0inv = luinv(sigma0)
	sigma0inv = (sigma0inv+sigma0inv')/2
	condV = J(k, k, 0)
	
	index = .
	w = .
	
	for(i=1; i<=n; i++){
		m0 = m_i[i,.]
		z0 = z_i[i,.]
		z_diff = select(z_i-repmat(z0,n),(1::n):!=i)
		vals = diagonal(z_diff*sigma0inv*z_diff')
		minindex(vals, 1, index, w)
		if(w[1,2]!=1){
			rng = runiform(1,rows(index))
			minindex(rng, 1, index, w)
			ix = index[1]
		}
		else{
			ix = index[1]
		}
		m_diff = (m0-select(m_i,(1::n):!=i)[ix,.])
		condV = condV+(m_diff')*(m_diff)/(2*n)
	}
	return (condV)
}


void sccintreg_calculation(string scalar Aname, string scalar bname, 
                       real scalar alpha, string scalar t_statsname, 
					   string scalar solname, string scalar rejectname,
					   string scalar cvname, real scalar tol){
					   	
	ineq_tolerance=-tol
	count_active = 0
	
	A = st_matrix(Aname) 
	b = st_matrix(bname)
	t_stats = st_numscalar(t_statsname)
	sol = st_matrix(solname)
	
	dm = length(A[.,1])
	p = length(A[1,.])-dm
	
	B = A[.,(1..(dm))]
	C = -A[.,((dm+1)..(dm+p))]
	
	muhat = sol[(1::(dm)),.]
	deltahat = sol[((dm+1)::(dm+p)),.]
	
	for(i=1; i<=length(b); i++){
		if( (B*muhat)[i] - (C*deltahat)[i] - b[i] >= ineq_tolerance ){
			count_active = count_active + 1
			if(count_active==1){
				B_active = B[i,.]
				C_active = C[i,.]
				b_active = b[i,.]
			}
			else{
				B_active = (B_active \ B[i,.])
				C_active = (C_active \ C[i,.])
				b_active = (b_active \ b[i,.])
			}
		}
	}
	
	if(count_active > 0){
		rhat = rank((B_active, C_active)) - rank(C_active)
		cv_scc = invchi2(rhat,(1-alpha))
		reject_scc = t_stats > cv_scc
    }
	else{
		reject_scc  = 0
	}
	
	st_numscalar(rejectname, reject_scc)
	st_numscalar(cvname, cv_scc)
}


end

