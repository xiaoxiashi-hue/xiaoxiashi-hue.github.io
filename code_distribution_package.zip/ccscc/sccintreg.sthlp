{smcl}
{* *! version 1.0.0 10sep2024}{...}
{cmd:help sccintreg}
{hline}

{title:Title}

{p2colset 5 18 20 2}{...}
{p2col :{hi:sccintreg} {hline 2}}Construct confidence intervals of linear regression models with an interval-measured outcome. {p_end}
{p2colreset}{...}

{title:Syntax}
{p 8 17 2}
{cmdab:sccintreg}
    {it:y_low}
	{it:y_up}
	{it:exog}
	{ifin}
	[{cmd:,}
	{cmd:alpha(}{it:real}{cmd:)}
	{cmdab:inst:rument(}{it:varname}{cmd:)}
	{cmd:subset(}{it:varname}{cmd:)}
	{cmdab:d:iscrete}
	{cmdab:nocons:tant}
	{cmd:sigma(}{it:matname}{cmd:)}
	{cmd:ub(}{it:matname}{cmd:)}
	{cmd:lb(}{it:matname}{cmd:)}
	{cmdab:prec:ision(}{it:real}{cmd:)}
	{cmd:relstep(}{it:real}{cmd:)}
	{cmd:activetol(}{it:real}{cmd:)}
	{cmd:qpabstol(}{it:real}{cmd:)}
	{cmd:qpreltol(}{it:real}{cmd:)}
	{cmd:qpfeastol(}{it:real}{cmd:)}
	{cmdab:grid:search(}{it:integer}{cmd:)}
	] 
	
{title:Description}

{p}{cmd:ccscc} uses the Python package cvxopt. Before using the command, one needs to complete the Python-Stata integration and configuration steps detailed in the appendix of Gong, Cox, and Shi (2024). The steps install Python 3.13 and cvxopt           for it and configure the Python executable path in Stata to point to the correct Python executable. The command will not work without these steps completed. {p_end}

{p}{cmd:sccintreg} returns confidence intervals of linear regression models with an interval-measured outcome.
Consider the linear regression model: Y* = X*beta+e, {bf:E}[e|X]=0.
The outcome Y* is unobserved. Instead, we observer an upper bound of it Yu and a lower bound Yl.

{p} {cmd:sccintreg} constructs confidence intervals based on testing moment inequalities: {bf:E}[(Yl-X*beta)|X]<=0 and {bf:E}[-(Yu-X*beta)|X]<=0.
The subvector inference method in Cox and Shi (2023) is used to calculate a marginal confidence interval of each coefficient, which is identical to an implementation of {cmd:ccscc}.
By default, it uses bisection to get lower and upper bounds of confidence intervals. However, grid search can also be employed by a user-specified option.

{title:Options}

{phang}{opt alpha(real)} sets the coverage rate of each confidence interval to 100(1−alpha)%. By default, it is set to 0.05.

{phang}{opt instrument} specifies the user-defined nonnegative instrument functions. Inside the parentheses, one should input a Stata variable list.

{phang}{opt subset} specifies the subset of regressors that the user wants to construct MCIs for. Inside the parentheses, one inputs a variable list that is a subset of the regressor list exog unless the MCI of the intercept is of interest. For example, subset("X1 X2") instructs Stata to report MCIs of the coefficients for variables "X1" and "X2". To include intercept, add "cons" to subset. For instance, subset("cons X1") returns MCIs of intercept and the coefficient for "X1". The order of variable list in subset is irrelevant in a sense that MCIs in the outcome table are always sorted in the same order as exog and the intercept always come first. For example, if exog is X1 X2 X3 and subset("X3 cons X1") is specified as option, then MCIs in the outcome table is ordered as: intercept, coefficient for "X1", and coefficient for "X3". If this option is not specified, MCIs for all the coefficients are reported.

{phang}{opt discrete} specifies that regressors are discrete.

{phang}{opt noconstant} instructs Stata that the constant term be excluded from the regression.

{phang}{opt sigma(matname)} specifies a user-defined variance-covariance estimator of standardized moments. Its argument matname should be the name of a Stata dM x dM positive-definite matrix.

{phang}{opt ub(matname)} specifies an upper bound vector for {cmd:beta_sub}, where {cmd:beta_sub} is a subvector of the full-coefficients {cmd:beta} that includes and only includes the coefficients for variables specified by the option {cmd:subset}. The argument matname should be the name of a Stata 1 x k matrix, where k is the dimension of {cmd:beta_sub}. By default, it is k-dimensional vectors whose elements are all 100.

{phang}{opt lb(matname)} specifies a lower bound vector for {cmd:beta_sub}, where {cmd:beta_sub} is explained above. The argument matname should be the name of a Stata 1 x k matrix, where k is the dimension of {cmd:beta_sub}. By default, it is k-dimensional vectors whose elements are all -100.

{phang}{opt precision} specifies a tolerance level for bisection algorithm. By default, it is {cmd:1e-08}.

{phang}{opt relstep} specifies a relative step size for bisection algorithm. By default, it is {cmd:1e-01}.

{phang}{opt activetol} specifies the tolerance level used to determine which inequalities are active. By default, it is {cmd:1e-05}.

{phang}{opt qpabstol, qpreltol, qpfeastol} sets `abstol', `reltol' and `feastol' for quadratic programming via CVXOPT (2023). See its documentation for precise description.

{phang}{opt gridsearch(int)} instructs Stata to use the grid search algorithm instead of bisection algorithm to find the end points of the CI. Its value should be the number of grid points. If {cmd:beta_l} and {cmd:beta_u} denote lb and ub, respectively, and {cmd:ng} is the number of grid points specified by gridsearch, then the resulting grid for {cmd:beta_j}, the jth coefficient of {cmd:beta_sub}, becomes {{cmd:beta_lj}+ m(cmd{beta:beta_uj} − {cmd:beta_lj})/(ng − 1) : m = 0, ..., ng − 1}, where {cmd:beta_lj} and {cmd:beta_uj} are the jth elements of {cmd:beta_l} and {cmd:beta_u}, respectively. If the user accidentally sets the argument of this option to 1 or does not specify it, then the bisection algorithm is used instead of the grid search.

{title:Stored results}

{pstd}
{cmd:cmitest} stores the following in {cmd:r()}:

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Scalars}{p_end}
{synopt:{cmd:r(N)}}number of observations{p_end}
{synopt:{cmd:r(alpha)}}nominal significance level{p_end}

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Matrix}{p_end}
{synopt:{cmd:r(table)}}table of marginal confidence intervals{p_end}
{synopt:{cmd:r(Tns)}}test statistics evaluated at each grid point (available only if {cmd:gridsearch} is used){p_end}
{synopt:{cmd:r(CVs)}}critical values evaluated at each grid point (available only if {cmd:gridsearch} is used){p_end}
{synopt:{cmd:r(TESTs)}}test results at each grid point, 1 if rejected and 0 otherwise (available only if {cmd:gridsearch} is used){p_end}
{synopt:{cmd:r(GRIDs)}}grid of parameter that is used is used(available only if {cmd:gridsearch} is used){p_end}

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Macros}{p_end}
{synopt:{cmd:r(cmd)}}{cmd:sccintreg}{p_end}
{synopt:{cmd:r(title)}}"Conditional Moment Inequalities Tests for Linear Regression with Interval Outcome"{p_end}

{p2colreset}{...}

{title:Examples} 
Consider X1 ~ Unif[0,1] and X2 ~ Unif[0,1] which are independent to each other.
Let the regression model becomes

Y* = {bf:beta0}+X1*{bf:beta1}+X2*{bf:beta2}+e, and {bf:E}[e|X1,X2] = 0.

The true parameters are set to {bf:beta0} = 0, {bf:beta1} = -1, and {bf:beta2} = -1.
We observe a lower bound Yl and an upper bound Yu of Y*.

First, open the data set. 

{stata clear all}

{stata use dataex2.dta , clear}

Then, we can simply get marginal confidence intervals of the regression coefficients as follows:

{stata sccintreg Yl Yu X1 X2}



{title:References}

Cox, G., and X. Shi. 2023. Simple Adaptive Size-Exact Testing for Full-Vector and Subvector Inference in Moment Inequality Models. {it:Review of Economic Studies}, Vol.90, 201-228. 

Gong, W., G. Cox, and X. Shi. 2024. Stata Commands for Full-vector and Subvector Inference in Moment Inequality Models. {it:Working paper}. 
