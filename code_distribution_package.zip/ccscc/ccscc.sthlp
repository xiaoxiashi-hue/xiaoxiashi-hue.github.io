{smcl}
{* *! version 1.0.0 10sep2024}{...}
{cmd:help ccscc}
{hline}

{title:Title}

{p2colset 5 18 20 2}{...}
{p2col :{hi:ccscc} {hline 2}}Implement the CC and sCC tests for moment-(in)equality hypotheses {p_end}
{p2colreset}{...}

{title:Syntax}
{p 8 17 2}
{cmdab:ccscc}
    ({it:instruments})
	{it:moments}
	{ifin}
	[{cmd:,}
	{cmd:alpha(}{it:real}{cmd:)}
	{cmdab:mati:neq(}{it:matname}{cmd:)}
	{cmdab:veci:neq(}{it:matname}{cmd:)}
	{cmdab:matn:uisa(}{it:matname}{cmd:)}
	{cmdab:ivd:iscrete}
	{cmdab:r:efined}
	{cmd:sigma(}{it:matname}{cmd:)}
	{cmd:activetol(}{it:real}{cmd:)}
	{cmd:qpabstol(}{it:real}{cmd:)}
	{cmd:qpreltol(}{it:real}{cmd:)}
	{cmd:qpfeastol(}{it:real}{cmd:)}
	] 
{p_end}
	
{title:Description}

{p}{cmd:ccscc} uses the Python package cvxopt. Before using the command, one needs to complete the Python-Stata integration and configuration steps detailed in the appendix of Gong, Cox, and Shi (2024). The steps install Python 3.13 and cvxopt           for it and configure the Python executable path in Stata to point to the correct Python executable. The command will not work without these steps completed. {p_end}

{p}{cmd:ccscc} implements the CC test for moment-(in)equality hypotheses and the sCC test for moment-(in)equality hypotheses with nuisance parameters. To implement {cmd:ccscc}, users first need to generate dM number of Stata variables {it:moments}. If it is for the sCC test, then Stata variables {it:instruments} should additionally be defined. 

{p} For the CC test, the null hypothesis of the CC test is H0: B{bf:E}[{it:moments}]<=d, where {bf:E}[{it:moments}] is the expectation of {it:moments}, B is a dB x dM matrix, d is a dB-dimensional vector, and the inequality is interpreted element-wise.

{p} For the sCC test, the null hypothesis is H0: B{bf:E}[{it:moments}|{it:instruments}]-C*delta<=d, where {bf:E}[{it:moments}|{it:instruments}] is the conditional expectation of {it:moments} given {it:instruments}, delta is a nuisance parameter that is dC-dimensional vector, and C is a dB x dC matrix. B and d are as before, and the inequality is interpreted element-wise.

{title:Options}

{phang}{opt alpha(real)} specifies the size of the test. By default, it is set to {cmd:0.05}. 

{phang}{opt matineq(matname)} specifies the matrix B. Inside the parentheses, {it:matname} should be the name of a dB x dM Stata matrix. If the option is not specified, then it becomes the dM x dM identity matrix.

{phang}{opt vecineq(matname)} specifies the vector d. Inside the parentheses, {it:matname} should be the name of a dB x 1 Stata matrix. If the option is not specified, then it becomes a dB-dimensional zero vector.

{phang}{opt matnuisa(matname)} specifies the matrix C. Inside the parentheses, {it:matname} should be the name of a dB x dC Stata matrix.

{phang}{opt ivdiscrete} specifies that the instruments are discrete. This option affects how the variance-covariance matrix of standardized moments is estimated as explained below. This option should not be specified for the CC test.

{phang}{opt refined} adjusts the critical value to make the size of the CC test more accurate. Details of it is provided in Section A.1 of Cox and Shi (2023). The refined sCC test is not implemented in the present code package, and thus this option should not be used when doing the sCC test.

{phang}{opt sigma(matnanme)} specifies a user-defined estimator of the variance-covariance matrix of standardized moments. Its argument {it:matname} should be the name of a Stata dM x dM  positive-definite matrix. If this option is not specified, the command calculates the variance-covariance estimator according to (18) in Section 3.1 of Cox and Shi (2023) for the CC test and according to (51) in Section A.5 of Cox and Shi (2023) for the sCC test if ivdiscrete is not specified and according to formula (28) in Section 3.2 of Cox and Shi (2023) otherwise.

{phang}{opt activetol(real)} specifies the tolerance level used to determine which inequalities are active. By default, it is set to {cmd:1e-05}.

{phang}{opt qpabstol(real)} sets `abstol' for quadratic programming via CVXOPT (2023). See its documentation for precise descriptions.

{phang}{opt qpreltol(real)} sets `reltol' for quadratic programming via CVXOPT (2023). See its documentation for precise descriptions.

{phang}{opt qpfeastol(real)} sets `feastol' for quadratic programming via CVXOPT (2023). See its documentation for precise descriptions.


{title:Stored results}

{pstd}
{cmd:ccscc} stores the following in {cmd:r()}:

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Scalars}{p_end}
{synopt:{cmd:r(N)}}number of observations{p_end}
{synopt:{cmd:r(alpha)}}nominal significance level of the test{p_end}
{synopt:{cmd:r(reject)}}1 if the test is rejected, 0 if not{p_end}
{synopt:{cmd:r(rank)}}rank of active moment-(in)equalities that determines the critical value of the test{p_end}
{synopt:{cmd:r(cv)}}critical value for the test{p_end}
{synopt:{cmd:r(t_stats)}}test statistic{p_end}
{synopt:{cmd:r(pval)}}p-value for the test{p_end}

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Matrix}{p_end}
{synopt:{cmd:r(Sigmainv)}}the inverse of estimated (conditional) variance-covariance matrix of standardized moments{p_end}

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Macros}{p_end}
{synopt:{cmd:r(cmd)}}{cmd:ccscc}{p_end}
{synopt:{cmd:r(title)}}"Conditional Moment Inequalities Test"{p_end}

{p2colreset}{...}

{title:Examples} 
Consider Z1 ~ N(0,1) and Z2 ~ N(0,1) which are independent to each other.
Suppose that our moment-inequality model is defined by {bf:E}[Z1-theta_1] <= 0 and {bf:E}[Z2-theta_2] <= 0.
We want to implement the CC test the null hypothesis H0: (theta_1, theta_2) = (0, 0).

First, open the data set. 

{stata clear all}

{stata use dataex1.dta , clear}

Then, construct variables whose moments compose the inequality hypothesis.

{stata generate m1 = Z1 - 0}

{stata generate m2 = Z2 - 0}

Define the matrix B and vector d for 

{stata matrix B = (1, 0 \ 0, 1)}

{stata matrix d = (0 \ 0)}

{stata ccscc () m1 m2, matineq(B) vecineq(d)}

For the sCC test, we refer to Gong, Cox, and Shi (2024)




{title:References}

Cox, G., and X. Shi. 2023. Simple Adaptive Size-Exact Testing for Full-Vector and Subvector Inference in Moment Inequality Models. {it:Review of Economic Studies}, Vol.90, 201-228. 

Gong, W., G. Cox, and X. Shi. 2024. Stata Commands for Full-vector and Subvector Inference in Moment Inequality Models. {it:Working paper}.


 